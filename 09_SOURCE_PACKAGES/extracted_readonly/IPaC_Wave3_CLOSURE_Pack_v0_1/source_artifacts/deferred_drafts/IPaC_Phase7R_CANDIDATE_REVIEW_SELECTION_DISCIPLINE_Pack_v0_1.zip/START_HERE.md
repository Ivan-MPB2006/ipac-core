# IPaC Phase 7R — Candidate Review & Selection Discipline Pack v0.1

**Дата сборки:** 2026-06-08  
**Статус:** accepted-candidate  
**Контур:** Wave 3 / Phase 7R  
**Назначение:** дисциплина ревью и выбора первого MVI-кандидата без перехода к execution.

## Текущая координата

```text
Recovery Program
├─ Wave 1 — Core Recovery ✅
├─ Wave 2 — Knowledge Recovery ✅
└─ Wave 3 — Validation / MVP Candidate Recovery
   ✅ Phase 7 — MVP / MVI Candidates
   ✅ Phase 7R — Candidate Review & Selection Discipline
```

## Главный результат

Phase 7R рекомендует **не запускать MVP**, а перейти к проектированию первого минимального проверочного теста.

Рекомендованная последовательность:

1. **MVI-IPAC-003 — Context Pack workflow**  
   Первый внутренний MVI-кандидат для проверки bootability и снижения context drift.

2. **MVI-IPAC-005 — Need → Artifact → Review cycle**  
   Компаньон / ядровой MVI для проверки превращения живого смысла в артефакт.

3. **MVI-IPAC-007 — External reviewer feedback loop**  
   Внешний тест, но только после отдельного field design.

## Критическое ограничение

```text
Phase 7R does not execute MVP.
Phase 7R selects candidates for test design and defines guards against false validation.
```
