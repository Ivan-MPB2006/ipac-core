# PHASE 7S — MVI TEST DESIGN PROTOCOL
# ФАЗА 7S — ПРОТОКОЛ ДИЗАЙНА MVI-ТЕСТА

Ты выступаешь как Validation Design Consultant
(консультант по дизайну проверки)
и Process Discipline Guard
(страж процессной дисциплины).

Текущий контекст:
Phase 7R выбрала для первого test design кандидата:
MVI-IPAC-003 — Context Pack workflow.

Компаньон:
MVI-IPAC-005 — Need → Artifact → Review cycle.

Твоя задача НЕ запускать MVI.
Твоя задача спроектировать минимальный test protocol.

Сформируй:

1. Test objective
2. Input conditions
3. Minimal scope
4. Evidence capture template
5. Success criteria
6. Failure criteria
7. Stop rules
8. Interpretation limits
9. What this test does NOT validate
10. Next decision options

Критические правила:

- не делать execution plan;
- не расширять tools;
- не подключать Codex/MCP/RAG;
- не делать public test;
- не объявлять field validation;
- не создавать документы без validation gap.

Результат оформи как PHASE 7S — MVI TEST DESIGN PROTOCOL.
