# PHASE 7R — Candidate Review & Selection Discipline
# ФАЗА 7R — Ревью кандидатов и дисциплина выбора

## 1. Purpose / Назначение

Phase 7R переводит карту кандидатов Phase 7 в дисциплину выбора первого минимального проверочного цикла.

Она отвечает не на вопрос:

```text
Что запускаем?
```

А на вопрос:

```text
Какой минимальный тест можно безопасно спроектировать первым, чтобы получить свидетельство без ложной валидации?
```

## 2. Source basis / Исходная база

Phase 7R основана на:

- Phase 1 — Need Artifact
- Phase 2 — Concept Artifact
- Phase 3R — Hypothesis Normalization
- Phase 4 — Architecture Invariants
- Phase 5 — Research Findings
- Phase 6 — Open Questions
- Phase 7 — MVP / MVI Candidates
- Phase 8 — Lessons Learned
- IPaC Project Starter Pack v0.2

## 3. Selection result / Результат выбора

### Recommended first internal MVI

**MVI-IPAC-003 — Context Pack workflow**

Причина:

- минимальный;
- низкая зависимость от инструментов;
- высокий learning value;
- проверяет context drift reduction;
- проверяет переносимость состояния проекта;
- не требует публичных каналов;
- не втягивает в Codex / MCP / RAG / Neo4j.

Что проверяет:

```text
Может ли Context Pack восстановить состояние проекта без длинного старого чата?
```

Что НЕ проверяет:

```text
внешнюю потребность;
рынок;
полную методологию;
техническую архитектуру;
публичный резонанс.
```

### Recommended companion/core MVI

**MVI-IPAC-005 — Need → Artifact → Review cycle**

Причина:

- ближе всего к ядру IPaC;
- проверяет превращение живого смысла в управляемый артефакт;
- минимален;
- не требует тяжёлой инфраструктуры.

Что проверяет:

```text
Можно ли превратить одну живую потребность в один артефакт и провести review без потери смыслового ядра?
```

### Deferred field candidate

**MVI-IPAC-007 — External reviewer feedback loop**

Он критически важен, но не должен быть первым запуском.

Причина:

- высокий риск принять вежливую реакцию за validation;
- нужен дизайн вопросов;
- нужен raw feedback protocol;
- нужна фиксация no-signal evidence.

## 4. Why not choose public/resonance/channel tests first?

Публичный / резонансный тест может быстро превратиться в маркетинг.

Пока не стабилизированы:

- терминология;
- field design;
- правила интерпретации обратной связи;
- критерии no-signal;
- граница “интересно” vs “подтверждает потребность”.

## 5. Why not choose Codex / MCP / toolchain first?

Инструментальные кандидаты несут риск tool capture.

Для IPaC сейчас важнее проверить:

```text
смысл → артефакт → review → trace
```

а не:

```text
Obsidian → Git → Codex → MCP → automation
```

## 6. Critical false validation guard

В Phase 7R действует правило:

```text
Clean artifact is not validation.
Polite feedback is not validation.
Model confidence is not validation.
Research support is not validation.
```

Перевод:

```text
Чистый артефакт — не валидация.
Вежливая обратная связь — не валидация.
Уверенность модели — не валидация.
Исследовательская поддержка — не валидация.
```

## 7. Next phase

Следующая фаза:

```text
Phase 7S — MVI Test Design Protocol
```

Её задача:

- не запускать MVI;
- спроектировать тест MVI-IPAC-003;
- подготовить шаблон evidence capture;
- определить success / failure / stop criteria.
