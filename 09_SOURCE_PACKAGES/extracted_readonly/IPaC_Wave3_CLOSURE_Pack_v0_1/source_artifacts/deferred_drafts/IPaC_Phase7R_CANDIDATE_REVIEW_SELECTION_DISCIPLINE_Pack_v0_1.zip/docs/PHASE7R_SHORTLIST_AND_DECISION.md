# PHASE 7R — Shortlist and Decision

## Shortlist

| Rank | Candidate | Status | Role |
|---:|---|---|---|
| 1 | MVI-IPAC-003 — Context Pack workflow | selected for first test design | проверка bootability / context drift |
| 2 | MVI-IPAC-005 — Need → Artifact → Review cycle | selected as core companion | проверка ядра IPaC |
| 3 | MVI-IPAC-009 — AI-assisted concept recovery workflow | process evidence support | уже частично проявлен в Recovery Pipeline |
| 4 | MVI-IPAC-007 — External reviewer feedback loop | deferred until field design | внешняя проверка понимания / потребности |

## Decision

Phase 7R выбирает не “MVP к запуску”, а **первый кандидат для test design**.

Первый test design:

```text
MVI-IPAC-003 — Context Pack Bootability Test
```

Компаньон:

```text
MVI-IPAC-005 — Need → Artifact → Review Test
```

Отложенный внешний тест:

```text
MVI-IPAC-007 — External Reviewer Comprehension Test
```

## Why this order?

1. Сначала проверяется управляемость контекста.
2. Потом проверяется ядро “живой смысл → артефакт → review”.
3. Потом можно выводить ограниченный артефакт к внешнему рецензенту.

Такой порядок снижает риск:

- false validation;
- tool capture;
- channel-driven thinking;
- premature execution;
- document proliferation.
