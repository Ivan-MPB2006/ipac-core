# Phase 7R Source Policy

Phase 7R uses Phase 7 candidate registers as source material.

It does not add new candidates.
It does not run web research.
It does not create execution plan.
It does not claim field validation.

Phase 7R may recommend selection for test design based on already recovered candidates.
