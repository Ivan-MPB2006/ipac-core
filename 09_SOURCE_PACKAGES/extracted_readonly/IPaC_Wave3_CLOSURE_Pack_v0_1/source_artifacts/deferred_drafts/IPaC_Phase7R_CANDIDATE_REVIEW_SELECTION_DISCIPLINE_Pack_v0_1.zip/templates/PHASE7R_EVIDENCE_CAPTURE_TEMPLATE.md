# PHASE7R Evidence Capture Template

```yaml
test_id:
candidate_id:
date:
evidence_source:
evidence_level:
```

## 1. Raw input

## 2. Raw output / raw observation

## 3. What this evidence may support

## 4. What this evidence does NOT support

## 5. Risk of misinterpretation

## 6. Success / failure criteria check

## 7. Decision

Allowed decisions:

- keep_candidate
- revise_test_design
- park_candidate
- stop_candidate

## 8. Trace note
