# PHASE7R Candidate Decision Template

```yaml
candidate_id:
candidate_name:
review_date:
reviewer:
status: candidate_review
```

## 1. What does this candidate test?

## 2. What does it NOT test?

## 3. Minimum scope

## 4. Evidence expected

## 5. False validation risks

## 6. Stop conditions

## 7. Selection decision

Allowed decisions:

- select_for_first_test_design
- select_as_companion
- defer_until_field_design
- park_for_later
- reject_as_noise

## 8. Rationale

## 9. Next action
