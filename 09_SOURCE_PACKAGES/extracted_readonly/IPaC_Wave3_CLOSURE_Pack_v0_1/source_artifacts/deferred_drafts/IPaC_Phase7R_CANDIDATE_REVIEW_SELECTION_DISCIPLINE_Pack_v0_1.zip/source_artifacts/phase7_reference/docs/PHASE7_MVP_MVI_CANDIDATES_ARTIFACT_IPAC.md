# PHASE 7 — MVP / MVI CANDIDATES ARTIFACT
# ФАЗА 7 — АРТЕФАКТ КАНДИДАТОВ В MVP / MVI

**Проект:** IPaC / Information Production as Code  
**Роли анализа:** Knowledge Recovery Analyst; Validation Strategy Consultant; MVP / MVI Scoping Analyst; Process Discipline Guard  
**Контур:** Phase 7 / Old Chat Recovery / MVP-MVI Candidate Map / Validation Strategy  
**Тип документа:** переносимый инженерный артефакт кандидатов MVP / MVI  
**Версия:** v0.1  
**Статус:** candidate  
**Source mode:** old_chat_recovery  
**No new web research:** true  
**Field validation claimed:** false  
**Execution plan created:** false  

---

## 0. Critical distinction

```text
MVP ≠ MVI ≠ execution plan ≠ product launch ≠ marketing campaign.
Phase 7 does not choose the final MVP.
Phase 7 maps candidate tests, evidence targets, risks and parked options.
```

## SECTION 1 — MVP / MVI CANDIDATE MAP

**Total candidates recovered:** 12

### By candidate type

| Candidate type | Count |
|---|---:|
| workflow_test | 5 |
| prototype_candidate | 2 |
| mvi_candidate | 2 |
| field_test | 1 |
| execution_signal | 1 |
| resonance_test | 1 |

### By readiness

| Readiness | Count |
|---|---:|
| needs_research | 1 |
| needs_field_design | 4 |
| ready_for_review | 4 |
| needs_architecture_review | 1 |
| premature | 1 |
| needs_terminology_clarification | 1 |

### By priority

| Priority | Count |
|---|---:|
| medium | 3 |
| high | 5 |
| critical | 4 |

---

### MVI-IPAC-001 — LLM Wiki / Karpathy-style experiment

**Type:** `workflow_test`  
**Readiness:** `needs_research`  
**Priority:** `medium`

**Description:** A small reference-driven experiment inspired by LLM literacy / Karpathy-style explanatory knowledge, used only to test whether IPaC can recover, structure and preserve an external knowledge topic.

**Tests hypothesis:** HYP-IPAC-008; HYP-IPAC-026

**Related need:** Make complex meaning manageable and portable.

**Related concept:** Context Pack; AI Mentor; Knowledge Artifact

**Related architecture invariant:** Artifact to bootable context flow; Human-AI collaboration boundary

**Related open question:** OQ-IPAC-006; OQ-IPAC-007

**Minimal scope:** One small LLM-related source/theme converted into a small knowledge artifact and reviewed for recoverability.

**Expected field evidence:** Artifact quality review; context recovery signal; concept clarity signal.

**What it does NOT validate:** Does not validate IPaC market need, Meaning Bottleneck, or external adoption.

**Main risks:** authority borrowing; internal coherence mistaken for evidence; polished output instead of learning

**Stop condition:** Stop if source review becomes general LLM research instead of IPaC workflow test.

---

### MVI-IPAC-002 — Obsidian Vault / Knowledge Container MVP

**Type:** `prototype_candidate`  
**Readiness:** `needs_field_design`  
**Priority:** `high`

**Description:** A minimal Obsidian/Markdown container holding one Knowledge Clump with artifacts, trace, status and links.

**Tests hypothesis:** HYP-IPAC-019; HYP-IPAC-021; HYP-IPAC-022

**Related need:** Make living knowledge portable and externally recoverable.

**Related concept:** Knowledge Clump; Knowledge Artifact; Trace; Source-of-truth

**Related architecture invariant:** Portability invariant; Artifact to bootable context flow

**Related open question:** OQ-IPAC-008

**Minimal scope:** One small vault/folder with README, MANIFEST, status, one artifact, one trace file and one map.

**Expected field evidence:** Context drift reduction signal; traceability improvement signal; usage observation.

**What it does NOT validate:** Does not validate external need, business value or public communication.

**Main risks:** tool capture; document proliferation; internal coherence mistaken for field evidence

**Stop condition:** Stop if tool setup dominates learning.

---

### MVI-IPAC-003 — Context Pack workflow

**Type:** `workflow_test`  
**Readiness:** `ready_for_review`  
**Priority:** `critical`

**Description:** A minimal workflow for packaging context so a new Project/agent can recover state without long-chat dependency.

**Tests hypothesis:** HYP-IPAC-007; HYP-IPAC-026

**Related need:** Reduce context drift and preserve portability.

**Related concept:** Context Pack; Source-of-truth; AI Mentor

**Related architecture invariant:** Handoff flow between environments; Portability invariant

**Related open question:** OQ-IPAC-007

**Minimal scope:** One context pack with accepted context, status, artifact list, open questions and boot prompt.

**Expected field evidence:** Context drift reduction signal; recovery quality signal.

**What it does NOT validate:** Does not prove public value or full technical architecture.

**Main risks:** hidden context debt; false sense of bootability; polished package instead of recovery test

**Stop condition:** Stop if new Project cannot produce current status and next route.

---

### MVI-IPAC-004 — Recovery Prompt pipeline

**Type:** `workflow_test`  
**Readiness:** `ready_for_review`  
**Priority:** `high`

**Description:** A chain of prompts that recovers Need, Concept, Hypotheses, Invariants, Research, Open Questions and Lessons from old chat material.

**Tests hypothesis:** HYP-IPAC-025; HYP-IPAC-026

**Related need:** Recover complex knowledge from long chat into structured artifacts.

**Related concept:** AI-assisted concept recovery workflow; Knowledge Artifact; Trace

**Related architecture invariant:** Living impulse to structured artifact flow; Artifact to bootable context flow

**Related open question:** OQ-IPAC-006; OQ-IPAC-013

**Minimal scope:** Run recovery on one bounded thread segment and compare outputs to accepted artifacts.

**Expected field evidence:** Artifact quality review; traceability improvement signal.

**What it does NOT validate:** Does not validate external market need or public terminology.

**Main risks:** AI over-synthesis; false coherence; document proliferation

**Stop condition:** Stop if outputs become plausible but not traceable to source context.

---

### MVI-IPAC-005 — Need → Artifact → Review cycle

**Type:** `mvi_candidate`  
**Readiness:** `ready_for_review`  
**Priority:** `critical`

**Description:** A minimal cycle where one real need is transformed into one artifact and reviewed for whether living meaning was preserved.

**Tests hypothesis:** HYP-IPAC-003; HYP-IPAC-004

**Related need:** Living complex meaning becomes manageable, portable, checkable artifact.

**Related concept:** Living Meaning; Knowledge Artifact; Review

**Related architecture invariant:** Knowledge lifecycle invariant; Human-AI collaboration boundary

**Related open question:** OQ-IPAC-002; OQ-IPAC-003

**Minimal scope:** One need; one artifact; one review; one trace note.

**Expected field evidence:** Artifact quality review; preservation-of-meaning signal.

**What it does NOT validate:** Does not validate full IPaC architecture, toolchain, or external adoption.

**Main risks:** internal coherence mistaken for field evidence; dead documentation; false validation

**Stop condition:** Stop if review cannot distinguish preserved meaning from polished output.

---

### MVI-IPAC-006 — Canon / Trace / Review / Decision / Controlled Rebuild cycle

**Type:** `prototype_candidate`  
**Readiness:** `needs_architecture_review`  
**Priority:** `critical`

**Description:** A minimal internal prototype of the full living knowledge governance loop.

**Tests hypothesis:** HYP-IPAC-004; HYP-IPAC-013

**Related need:** Make knowledge revisable without losing continuity.

**Related concept:** Canon; Trace; Review; Decision; Controlled Rebuild

**Related architecture invariant:** Feedback → Review → Canon; Canon ↔ Trace; Knowledge lifecycle invariant

**Related open question:** OQ-IPAC-004; OQ-IPAC-015

**Minimal scope:** One canon entry; one feedback item; one review; one decision; one controlled rebuild; one trace update.

**Expected field evidence:** Traceability improvement signal; controlled rebuild signal.

**What it does NOT validate:** Does not validate external demand or public language.

**Main risks:** architecture creep; bureaucracy; feedback chaos

**Stop condition:** Stop if the loop becomes heavier than the knowledge item.

---

### MVI-IPAC-007 — External reviewer feedback loop

**Type:** `field_test`  
**Readiness:** `needs_field_design`  
**Priority:** `critical`

**Description:** A small controlled feedback loop where one external reviewer evaluates a concept/artifact for clarity and usefulness.

**Tests hypothesis:** HYP-IPAC-001; HYP-IPAC-003; HYP-IPAC-017

**Related need:** Check whether IPaC concepts are externally understandable.

**Related concept:** Field Evidence; Knowledge Clump; Meaning Bottleneck

**Related architecture invariant:** Projection / Use → Feedback / Evidence

**Related open question:** OQ-IPAC-011; OQ-IPAC-012; OQ-IPAC-021

**Minimal scope:** One artifact; one reviewer; written feedback; one interpretation note.

**Expected field evidence:** Written feedback; concept clarity signal.

**What it does NOT validate:** Does not validate market demand or full methodology.

**Main risks:** polite feedback mistaken for validation; reviewer bias; false resonance

**Stop condition:** Stop if feedback is treated as validation without review.

---

### MVI-IPAC-008 — Field evidence collection loop

**Type:** `workflow_test`  
**Readiness:** `needs_field_design`  
**Priority:** `high`

**Description:** A minimal process for capturing raw evidence, preserving it, classifying it and preventing premature interpretation.

**Tests hypothesis:** HYP-IPAC-011; HYP-IPAC-012; HYP-IPAC-013

**Related need:** Turn feedback into evidence without false maturity.

**Related concept:** Feedback / Evidence; Review; Field Evidence

**Related architecture invariant:** Feedback → Review → Canon relationship

**Related open question:** OQ-IPAC-013; OQ-IPAC-014; OQ-IPAC-015

**Minimal scope:** Three raw evidence entries; one classification pass; no canon update.

**Expected field evidence:** Raw feedback preservation signal; evidence discipline signal.

**What it does NOT validate:** Does not validate concept quality or audience resonance by itself.

**Main risks:** feedback chaos; overclassification; internal coherence mistaken for evidence

**Stop condition:** Stop if raw evidence is being interpreted before preservation.

---

### MVI-IPAC-009 — AI-assisted concept recovery workflow

**Type:** `workflow_test`  
**Readiness:** `ready_for_review`  
**Priority:** `high`

**Description:** A controlled workflow where AI recovers concepts from previous work and separates concept, hypothesis, architecture, research and open questions.

**Tests hypothesis:** HYP-IPAC-025; HYP-IPAC-026

**Related need:** Recover complex knowledge without losing distinctions.

**Related concept:** AI Mentor; Knowledge Artifact; Context Pack

**Related architecture invariant:** Living impulse to structured artifact flow; Maturity separation

**Related open question:** OQ-IPAC-006; OQ-IPAC-013

**Minimal scope:** One bounded source; one recovery artifact; one quality review against source.

**Expected field evidence:** Artifact quality review; level-separation signal.

**What it does NOT validate:** Does not validate external usefulness or field resonance.

**Main risks:** AI over-synthesis; false coherence; source drift

**Stop condition:** Stop if AI adds concepts not present in archive.

---

### MVI-IPAC-010 — Obsidian + ChatGPT Project + Codex handoff

**Type:** `execution_signal`  
**Readiness:** `premature`  
**Priority:** `medium`

**Description:** A possible later handoff test between human-facing knowledge workspace, ChatGPT Project and execution agent.

**Tests hypothesis:** HYP-IPAC-023; HYP-IPAC-024

**Related need:** Connect knowledge artifacts to execution without losing concept boundaries.

**Related concept:** Context Pack; Knowledge Artifact; AI Mentor

**Related architecture invariant:** Handoff flow between environments; Architecture vs execution boundary

**Related open question:** OQ-IPAC-017; OQ-IPAC-018

**Minimal scope:** One artifact handed from Project to Codex for a non-critical file operation, later.

**Expected field evidence:** Handoff traceability signal; execution boundary signal.

**What it does NOT validate:** Does not validate concept, external need, or architecture by itself.

**Main risks:** tool capture; execution pull; premature technical architecture

**Stop condition:** Stop if tool integration starts driving conceptual decisions.

---

### MVI-IPAC-011 — Small publication / resonance test

**Type:** `resonance_test`  
**Readiness:** `needs_terminology_clarification`  
**Priority:** `medium`

**Description:** A small controlled external communication test of a single concept or artifact, not a campaign.

**Tests hypothesis:** HYP-IPAC-001; HYP-IPAC-017

**Related need:** Check whether external environment recognizes the Meaning Bottleneck or IPaC language.

**Related concept:** Projection; Meaning Bottleneck; Field Evidence

**Related architecture invariant:** Projection / Use → Feedback / Evidence

**Related open question:** OQ-IPAC-011; OQ-IPAC-021

**Minimal scope:** One small message or artifact to one limited audience with raw feedback capture.

**Expected field evidence:** Written response; weak/strong signal; no-signal evidence.

**What it does NOT validate:** Does not validate full IPaC, market demand, or product readiness.

**Main risks:** marketing drift; channel-driven thinking; false validation

**Stop condition:** Stop if goal shifts from learning to visibility.

---

### MVI-IPAC-012 — Decision-support micro-case

**Type:** `mvi_candidate`  
**Readiness:** `needs_field_design`  
**Priority:** `high`

**Description:** A tiny decision-support case where one ambiguous knowledge/decision situation is converted into options, evidence, review and decision trace.

**Tests hypothesis:** HYP-IPAC-002; HYP-IPAC-004; HYP-IPAC-013

**Related need:** Make meaning actionable and improve decision quality.

**Related concept:** Decision; Review; Trace; Knowledge Artifact

**Related architecture invariant:** Feedback → Review → Canon; Human Subject owns judgement

**Related open question:** OQ-IPAC-004; OQ-IPAC-015

**Minimal scope:** One micro-decision; one evidence note; one options table; one decision trace.

**Expected field evidence:** Decision quality signal; traceability improvement signal.

**What it does NOT validate:** Does not validate external market need or public communication.

**Main risks:** internal coherence mistaken for decision quality; overprocessing; false validation

**Stop condition:** Stop if process produces more complexity than decision clarity.

---

## SECTION 2 — HYPOTHESIS LINKAGE

Candidate-to-hypothesis linkage is encoded in `registers/PHASE7_MVP_MVI_CANDIDATES_REGISTER.csv` and `registers/PHASE7_VALIDATION_TARGETS_REGISTER.csv`.

Rule:

```text
Phase 7 only proposes tests.
It does not upgrade any hypothesis to validated.
```

## SECTION 3 — VALIDATION TARGETS

### VT-IPAC-001 — Real external need

**Why important:** Foundation of relevance.

**Related hypothesis:** HYP-IPAC-001; HYP-IPAC-002

**Related open question:** OQ-IPAC-001

**Candidate tests:** MVI-IPAC-007; MVI-IPAC-011

**Minimum evidence needed:** External reviewer recognizes the need and gives concrete example.

**False validation risk:** Polite agreement mistaken for demand.

### VT-IPAC-002 — Living meaning can become manageable artifact

**Why important:** Core IPaC transformation claim.

**Related hypothesis:** HYP-IPAC-003; HYP-IPAC-004

**Related open question:** OQ-IPAC-002

**Candidate tests:** MVI-IPAC-005; MVI-IPAC-009

**Minimum evidence needed:** Reviewer can see meaning preserved in artifact and trace.

**False validation risk:** Beautiful artifact mistaken for preserved meaning.

### VT-IPAC-003 — Human + AI can hold complexity better than long chat

**Why important:** Collaboration model depends on this.

**Related hypothesis:** HYP-IPAC-008; HYP-IPAC-009

**Related open question:** OQ-IPAC-006

**Candidate tests:** MVI-IPAC-003; MVI-IPAC-004; MVI-IPAC-009

**Minimum evidence needed:** Lower context drift and better artifact separation than raw chat.

**False validation risk:** AI fluency mistaken for complexity control.

### VT-IPAC-004 — Context Pack reduces context drift

**Why important:** Portation depends on it.

**Related hypothesis:** HYP-IPAC-007; HYP-IPAC-026

**Related open question:** OQ-IPAC-007

**Candidate tests:** MVI-IPAC-003

**Minimum evidence needed:** New Project recovers status and next route without long chat.

**False validation risk:** Good-looking boot answer mistaken for actual recovery.

### VT-IPAC-005 — Canon / Trace / Review / Decision / Controlled Rebuild works

**Why important:** Core architecture loop.

**Related hypothesis:** HYP-IPAC-004; HYP-IPAC-013

**Related open question:** OQ-IPAC-004; OQ-IPAC-015

**Candidate tests:** MVI-IPAC-006; MVI-IPAC-012

**Minimum evidence needed:** One reviewed update improves canon while preserving trace.

**False validation risk:** Overbuilt process mistaken for governance.

### VT-IPAC-006 — Obsidian / Git / Project can act as stable external memory

**Why important:** Tool support must be tested without tool capture.

**Related hypothesis:** HYP-IPAC-019; HYP-IPAC-021; HYP-IPAC-022

**Related open question:** OQ-IPAC-008

**Candidate tests:** MVI-IPAC-002; MVI-IPAC-010

**Minimum evidence needed:** Before/after context recovery improves using external memory.

**False validation risk:** Tool enthusiasm mistaken for system validation.

### VT-IPAC-007 — AI can act as process consultant, not only answer generator

**Why important:** AI Mentor concept depends on process discipline.

**Related hypothesis:** HYP-IPAC-008; HYP-IPAC-025

**Related open question:** OQ-IPAC-006; OQ-IPAC-013

**Candidate tests:** MVI-IPAC-004; MVI-IPAC-009

**Minimum evidence needed:** AI identifies levels, risks and recovery routes, not just text output.

**False validation risk:** Polished structure mistaken for process consulting.

### VT-IPAC-008 — External reviewers can understand IPaC without excessive simplification

**Why important:** Public language and terminology depend on it.

**Related hypothesis:** HYP-IPAC-017; HYP-IPAC-003

**Related open question:** OQ-IPAC-011; OQ-IPAC-012; OQ-IPAC-021

**Candidate tests:** MVI-IPAC-007; MVI-IPAC-011

**Minimum evidence needed:** Reviewer can explain concept back with minimal distortion.

**False validation risk:** Agreement without comprehension.

### VT-IPAC-009 — Feedback can be converted into controlled rebuild

**Why important:** Living knowledge must learn without chaos.

**Related hypothesis:** HYP-IPAC-004; HYP-IPAC-013

**Related open question:** OQ-IPAC-015

**Candidate tests:** MVI-IPAC-006; MVI-IPAC-008

**Minimum evidence needed:** Feedback leads to traceable decision candidate, not immediate rewrite.

**False validation risk:** Feedback chaos mistaken for learning.

### VT-IPAC-010 — IPaC is not just renamed Knowledge Engineering

**Why important:** Intellectual honesty and positioning.

**Related hypothesis:** HYP-IPAC-002; HYP-IPAC-009

**Related open question:** OQ-IPAC-009; OQ-IPAC-010

**Candidate tests:** MVI-IPAC-001; MVI-IPAC-012; research review

**Minimum evidence needed:** Comparative review identifies clear difference or overlap.

**False validation risk:** Rebranding existing field.

## SECTION 4 — MINIMAL FIELD EVIDENCE

Field evidence candidates are stored in `registers/PHASE7_FIELD_EVIDENCE_REGISTER.csv`.

Critical rule:

```text
Internal coherence is not field evidence.
Polished output is not field evidence.
Field evidence must include source, context, limitation and what it cannot prove.
```

## SECTION 5 — MVP / MVI SCOPING

Each candidate has minimal scope, includes, excludes, needed tools, not-needed tools, scope creep signs and stop conditions in the main candidate register and candidate review template.

Scoping rule:

```text
New documents are created only if they close a validation gap or execution gap.
Phase 7 itself does not create the execution documents.
```

## SECTION 6 — CANDIDATE RISK ANALYSIS

Candidate risks are stored in `registers/PHASE7_CANDIDATE_RISK_REGISTER.csv`.

Main recurring risks:

```text
false validation
internal coherence mistaken for field evidence
architecture creep
execution pull
tool capture
channel-driven thinking
document proliferation
polished output instead of learning
feedback chaos
loss of living meaning
```

## SECTION 7 — CANDIDATE PRIORITIZATION

Preliminary prioritization is stored in `registers/PHASE7_CANDIDATE_PRIORITY_REGISTER.csv`.

Important limitation:

```text
The ranking is preliminary.
It does not select the final MVP / MVI.
Selection must happen in Wave 3 Candidate Review / MVP-MVI Selection Discipline.
```

Highest preliminary learning-value / complexity candidates:

```text
MVI-IPAC-003 — Context Pack workflow
MVI-IPAC-005 — Need → Artifact → Review cycle
MVI-IPAC-007 — External reviewer feedback loop
MVI-IPAC-009 — AI-assisted concept recovery workflow
```

## SECTION 8 — WHAT PHASE 7 MUST NOT DO

Do not launch now:

```text
Small publication / resonance test before terminology and field design.
Obsidian + ChatGPT Project + Codex handoff before concept and handoff boundaries are stable.
Full toolchain / MCP / RAG / Neo4j implementation.
Full MVP product.
Multi-channel public campaign.
Dashboard-driven execution.
```

Need Phase 6 resolution first:

```text
Meaning Bottleneck external clarity.
Knowledge Clump terminology.
Field evidence thresholds.
Architecture vs execution boundary.
Research support vs validation boundary.
```

## SECTION 9 — MVP / MVI CANDIDATES REGISTER

CSV-ready table: `registers/PHASE7_MVP_MVI_CANDIDATES_REGISTER.csv`.

## SECTION 10 — VALIDATION TARGETS REGISTER

CSV-ready table: `registers/PHASE7_VALIDATION_TARGETS_REGISTER.csv`.

## SECTION 11 — FIELD EVIDENCE REGISTER

CSV-ready table: `registers/PHASE7_FIELD_EVIDENCE_REGISTER.csv`.

## SECTION 12 — PARKED / REJECTED CANDIDATES

Parked/rejected candidates are stored in `registers/PHASE7_PARKED_REJECTED_CANDIDATES_REGISTER.csv`.

None of the recovered candidates are rejected as noise in this artifact. Several are parked because they are premature, too tool-dependent, or likely to become execution/marketing rather than validation.

## SECTION 13 — FINAL SUMMARY

1. **Recovered candidates:** 12 MVP/MVI/prototype/workflow/field/resonance candidates were recovered.
2. **Most promising for critical hypotheses:** Context Pack workflow; Need → Artifact → Review; External reviewer feedback loop; AI-assisted concept recovery workflow.
3. **Premature candidates:** Obsidian + ChatGPT Project + Codex handoff; full toolchain; small publication/resonance test before terminology and field design.
4. **Best learning value / complexity ratio:** Context Pack workflow and Need → Artifact → Review cycle appear strongest preliminarily, but this is not final selection.
5. **Highest false validation risk:** Small publication/resonance test; external reviewer feedback loop; polished AI-assisted recovery workflow.
6. **What cannot be launched now:** product MVP, public campaign, full toolchain, Codex/MCP/RAG/Neo4j implementation, multi-channel release.
7. **Next step after Phase 7:** WAVE 3 CANDIDATE REVIEW / MVP-MVI SELECTION DISCIPLINE.