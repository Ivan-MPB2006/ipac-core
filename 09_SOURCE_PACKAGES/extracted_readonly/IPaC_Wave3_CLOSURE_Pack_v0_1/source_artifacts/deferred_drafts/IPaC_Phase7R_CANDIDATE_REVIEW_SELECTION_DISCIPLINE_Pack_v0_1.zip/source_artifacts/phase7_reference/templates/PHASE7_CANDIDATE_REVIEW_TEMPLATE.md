# PHASE7_CANDIDATE_REVIEW_TEMPLATE.md

```yaml
candidate_id:
candidate_name:
review_date:
reviewer:
candidate_type:
readiness:
```

## 1. Is this candidate recovered from previous work?

```text
yes / no / unclear
```

## 2. What hypothesis does it test?

```text

```

## 3. What open question does it address?

```text

```

## 4. What is the minimum scope?

```text

```

## 5. What evidence can it produce?

```text
written feedback / usage observation / before-after comparison / artifact quality review / decision quality signal / context drift reduction signal / traceability improvement signal
```

## 6. What does it NOT validate?

```text

```

## 7. False validation risk

```text
low / medium / high
```

## 8. Scope creep signs

```text

```

## 9. Stop condition

```text

```

## 10. Import decision

```text
import_to_mvp_candidates / import_to_validation_backlog / import_to_field_test_candidates / import_to_execution_candidates / park_for_later / reject_as_noise
```
