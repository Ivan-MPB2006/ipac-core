# MANIFEST.md

# IPaC Phase 7R — Candidate Review & Selection Discipline Pack v0.1

| Путь | Назначение |
|---|---|
| `README.txt` | |
| `START_HERE.md` | |
| `docs/PHASE7R_CANDIDATE_REVIEW_SELECTION_DISCIPLINE.md` | |
| `docs/PHASE7R_FALSE_VALIDATION_GUARDS.md` | |
| `docs/PHASE7R_NEXT_COORDINATES.md` | |
| `docs/PHASE7R_SHORTLIST_AND_DECISION.md` | |
| `maps/PHASE7R_SELECTION_FLOW.mmd` | |
| `maps/PHASE7R_TEST_DESIGN_PREVIEW.mmd` | |
| `prompts/PHASE7S_MVI_TEST_DESIGN_PROTOCOL_PROMPT.md` | |
| `registers/PHASE7R_CANDIDATE_REVIEW_REGISTER.csv` | |
| `registers/PHASE7R_FIELD_EVIDENCE_DESIGN_REGISTER.csv` | |
| `registers/PHASE7R_NEXT_ACTIONS_REGISTER.csv` | |
| `registers/PHASE7R_SELECTION_DECISION_REGISTER.csv` | |
| `registers/PHASE7R_STOP_RULES_REGISTER.csv` | |
| `source_artifacts/phase7_reference/docs/PHASE7_MVP_MVI_CANDIDATES_ARTIFACT_IPAC.md` | |
| `source_artifacts/phase7_reference/registers/PHASE7_CANDIDATE_PRIORITY_REGISTER.csv` | |
| `source_artifacts/phase7_reference/registers/PHASE7_FIELD_EVIDENCE_REGISTER.csv` | |
| `source_artifacts/phase7_reference/registers/PHASE7_MVP_MVI_CANDIDATES_REGISTER.csv` | |
| `source_artifacts/phase7_reference/registers/PHASE7_PARKED_REJECTED_CANDIDATES_REGISTER.csv` | |
| `source_artifacts/phase7_reference/registers/PHASE7_VALIDATION_TARGETS_REGISTER.csv` | |
| `source_artifacts/phase7_reference/status/PHASE7_MVP_MVI_CANDIDATES_status.json` | |
| `source_artifacts/phase7_reference/templates/PHASE7_CANDIDATE_REVIEW_TEMPLATE.md` | |
| `source_notes/PHASE7R_SOURCE_POLICY.md` | |
| `status/PHASE7R_status.json` | |
| `templates/PHASE7R_CANDIDATE_DECISION_TEMPLATE.md` | |
| `templates/PHASE7R_EVIDENCE_CAPTURE_TEMPLATE.md` | |

## Critical rule

```text
Phase 7R selects candidates for test design.
It does not launch MVP, create execution plan, or claim validation.
```
