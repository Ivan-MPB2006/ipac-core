# MANIFEST.md

# IPaC Phase 8 — LESSONS LEARNED ARTIFACT Pack v0.1

| Путь | Назначение |
|---|---|
| `docs/PHASE8_LESSONS_LEARNED_ARTIFACT_IPAC.md` | основной артефакт извлечённых уроков |
| `registers/PHASE8_LESSONS_LEARNED_REGISTER.csv` | CSV-ready реестр уроков |
| `registers/PHASE8_ANTIPATTERN_REGISTER.csv` | реестр анти-паттернов |
| `registers/PHASE8_PROJECT_RULES_REGISTER.csv` | правила для нового Project |
| `maps/PHASE8_PROCESS_FAILURE_MAP.mmd` | Mermaid-карта сбоев процесса |
| `templates/PHASE8_SESSION_REVIEW_TEMPLATE.md` | шаблон ревью сессии |
| `status/PHASE8_LESSONS_LEARNED_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Critical distinction

```text
validated ≠ field validated
execution candidate ≠ architecture
beautiful synthesis ≠ validation
chat ≠ source-of-truth
```
