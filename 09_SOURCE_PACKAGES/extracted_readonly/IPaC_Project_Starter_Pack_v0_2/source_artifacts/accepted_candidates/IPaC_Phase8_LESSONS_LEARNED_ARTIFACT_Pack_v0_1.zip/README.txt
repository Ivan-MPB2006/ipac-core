IPaC Phase 8 — LESSONS LEARNED ARTIFACT Pack v0.1

Назначение:
Пакет извлекает process intelligence из старой работы, чтобы новый Project не повторил старые ошибки.

Это НЕ развитие IPaC.
Это НЕ новая архитектура.
Это НЕ MVP.
Это НЕ execution plan.
Это НЕ маркетинговый текст.

Использование:
1. Прочитать docs/PHASE8_LESSONS_LEARNED_ARTIFACT_IPAC.md.
2. Импортировать mandatory/stop/review/artifact rules из registers/PHASE8_PROJECT_RULES_REGISTER.csv в правила нового Project.
3. Использовать templates/PHASE8_SESSION_REVIEW_TEMPLATE.md после крупных сессий.
4. Держать anti-pattern register как process guardrail.
5. Помнить: validated = internal/artifact-supported unless field-tested explicitly.

Главная цель:
Не красивый отчёт, а process intelligence для нового Project.
