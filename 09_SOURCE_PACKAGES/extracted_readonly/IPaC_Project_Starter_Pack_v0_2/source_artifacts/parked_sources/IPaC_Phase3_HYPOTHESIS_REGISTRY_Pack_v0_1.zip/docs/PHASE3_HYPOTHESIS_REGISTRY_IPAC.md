# PHASE 3 — HYPOTHESIS REGISTRY
# Реестр гипотез

**Проект:** IPaC / Information Production as Code  
**Контур:** Phase 3 / Hypothesis Management / Evidence Discipline / MVI Validation  
**Тип документа:** отчуждаемый информационный артефакт / реестр гипотез  
**Версия:** v0.1  
**Статус:** accepted-candidate  
**Дата:** 2026-06-08  

---

## 0. Назначение документа

Этот документ фиксирует гипотезы, возникшие в ходе разработки IPaC, и разделяет их по степени подтверждённости.

Главная задача Phase 3 — не расширять архитектуру, а определить, какие предположения уже можно использовать как рабочую основу, какие требуют проверки через MVI, какие остаются спекулятивными, а какие противоречивы или нерешены.

Статусы гипотез:

```text
validated — подтверждена
partially supported — частично подтверждена
speculative — спекулятивная
contradictory — противоречивая
unresolved — не разрешена
```

---

## 1. Сводка статусов

| Статус | Количество |
|---|---:|
| validated | 13 |
| partially supported | 17 |
| speculative | 5 |
| contradictory | 0 |
| unresolved | 7 |

---

## 2. Реестр гипотез

### HYP-IPAC-001 — Output became cheap; meaning became the bottleneck

**Статус:** `partially supported`

**Описание:**

AI sharply reduces the cost and friction of producing text, summaries, drafts, reports and other outputs, but does not automatically produce relevance, context, shared understanding, better decisions or action.

**Evidence / основания:**

This became the central Meaning Bottleneck formula and repeatedly structured LinkedIn, Site, Telegram, Pinterest and YouTube asset packs. It is strongly coherent conceptually, but still needs external validation through MVI feedback.

**Unresolved questions / открытые вопросы:**

Which audiences recognize the bottleneck first? Is the phrase immediately understandable outside the project? Does it resonate more with knowledge management, content operations, AI transformation or executive decision-making audiences?

---

### HYP-IPAC-002 — Organizations need information production engineering, not just AI-assisted content generation

**Статус:** `partially supported`

**Описание:**

Organizations will need a discipline for producing, tracing, validating, updating and reusing knowledge outputs, not merely faster AI-assisted drafting.

**Evidence / основания:**

The hypothesis follows from the persistent critique of ordinary documents, content operations, knowledge management and project management as insufficient alone. It is conceptually supported by the IPaC frame and by the need artifact.

**Unresolved questions / открытые вопросы:**

What exact organizational role will first feel this need? Is the entry point strategy, knowledge management, documentation engineering, AI governance, product operations or executive decision support?

---

### HYP-IPAC-003 — Knowledge Clumps are more than document collections

**Статус:** `validated`

**Описание:**

A Knowledge Clump is not a folder of files; it is a structured and emergent knowledge formation containing artifacts, context, history, decisions, feedback, use, trace and implicit meaning.

**Evidence / основания:**

The concept was repeatedly defined, operationalized through README/MANIFEST/status/registers/trace, contrasted with documents and frames, and used as the core object of IPaC.

**Unresolved questions / открытые вопросы:**

What minimal metadata is required for a Knowledge Clump to remain alive and portable? How much trace is enough before overhead becomes excessive?

---

### HYP-IPAC-004 — Living knowledge requires circulation through use, feedback and rebuild

**Статус:** `validated`

**Описание:**

Knowledge becomes living when it enters use, receives feedback, changes action, undergoes review and returns to canon as an updated structure.

**Evidence / основания:**

This became a mature concept across living knowledge circulation, feedback package, 71 Review, 72 Decision and 73 Trace. It underlies the full lifecycle diagrams.

**Unresolved questions / открытые вопросы:**

Which feedback signals are sufficient to trigger review? How should weak signals be accumulated without overinterpreting them?

---

### HYP-IPAC-005 — A system of living knowledge circulation is more appropriate than document workflow

**Статус:** `validated`

**Описание:**

The project should not be framed as document management or document workflow; it requires a system for the circulation, validation, updating and trace of living knowledge.

**Evidence / основания:**

The user explicitly rejected 'document workflow' as too narrow. The project repeatedly reframed around living knowledge circulation and meaning production.

**Unresolved questions / открытые вопросы:**

What terminology will be most understandable publicly: living knowledge circulation, knowledge circulation system, knowledge operating system, or information production as code?

---

### HYP-IPAC-006 — IPaC can function as an operating system for living knowledge

**Статус:** `partially supported`

**Описание:**

IPaC can be understood as a specialized operating system for a domain: information production as code, including boot, runtime, execution, feedback, review and trace.

**Evidence / основания:**

The SOS IPaC metaphor generated productive architecture: boot, runtime, dashboard, status registers, Mentor Layer, MVI, 71–73 route. It proved highly generative internally.

**Unresolved questions / открытые вопросы:**

Does the operating system metaphor help external audiences or overcomplicate positioning? Should it remain internal architecture language at first?

---

### HYP-IPAC-007 — Bootability is essential for preserving project continuity across plans, projects and agents

**Статус:** `validated`

**Описание:**

A project cannot be reliably moved to a new tariff plan, Project or AI agent by files alone; it needs boot sources, instructions, status recovery and recovery commands.

**Evidence / основания:**

The portation phase required Mentor Layer, Boot Protocol, First Boot Message, core source order, expected boot output and Recovery Mode.

**Unresolved questions / открытые вопросы:**

What is the minimal boot pack size? Which sources are essential, and which should be loaded only after the boot state is restored?

---

### HYP-IPAC-008 — AI Mentor Layer can preserve intersubjective collaboration across environments

**Статус:** `partially supported`

**Описание:**

An AI Mentor Layer can transmit not only information, but a mode of work: intersubjective collaboration, anti-generic behavior, current status, execution pivot, boot and handoff discipline.

**Evidence / основания:**

The AI Mentor Layer was explicitly defined and packaged. It has strong internal coherence and is being used for portation.

**Unresolved questions / открытые вопросы:**

Will a new Project actually reproduce the interaction quality after receiving the prompt and sources? What parts of the mode are prompt-transferable and what depends on accumulated conversational history?

---

### HYP-IPAC-009 — Intersubjectivity improves human-AI creative engineering work

**Статус:** `partially supported`

**Описание:**

The productive mode is neither command-response nor autonomous AI architecture, but creative intersubjectivity: human provides living intention and direction; AI provides structure, frameworks, trace and operationalization.

**Evidence / основания:**

The interaction produced multiple coherent artifacts, concepts, diagrams and execution packs. The user repeatedly confirmed the felt quality of this mode.

**Unresolved questions / открытые вопросы:**

How can intersubjective work be made reproducible with other models, agents and projects? What are the failure modes when the AI becomes too generic or too directive?

---

### HYP-IPAC-010 — The human must remain the subject; AI may guide methodology but not own the intent

**Статус:** `validated`

**Описание:**

AI can act as a methodological mentor, but must not replace the human subject, appropriate authorship, make final strategic decisions or become a guru.

**Evidence / основания:**

The boundary was explicitly formulated in the AI Mentor Layer: AI Mentor does not replace the subject; it helps the subject pass intention through complexity.

**Unresolved questions / открытые вопросы:**

How should this boundary be enforced in multi-agent workflows where agents execute tasks with increasing autonomy?

---

### HYP-IPAC-011 — MVI is the correct first external validation form

**Статус:** `partially supported`

**Описание:**

The first external move should be a Minimum Viable Icebreaker, not a full marketing campaign, full product launch or complete public methodology release.

**Evidence / основания:**

MVI emerged as the execution pivot and was operationalized through 82–90: LinkedIn, Site, Telegram, Pinterest, YouTube, feedback package and review.

**Unresolved questions / открытые вопросы:**

How small can the first MVI be while still producing meaningful evidence? Should trusted reviewers precede public posting?

---

### HYP-IPAC-012 — The five-channel contour can operate as one external resonance system

**Статус:** `unresolved`

**Описание:**

LinkedIn, Site, Telegram, Pinterest and YouTube can work as distinct organs of one external resonance system rather than separate marketing channels.

**Evidence / основания:**

The roles were clearly defined and integrated in document 87, but actual channel execution has not yet occurred.

**Unresolved questions / открытые вопросы:**

Will five channels create synergy or operational overload? Which channel should lead? Which can remain prepared but inactive?

---

### HYP-IPAC-013 — LinkedIn is the strongest first professional resonance channel

**Статус:** `unresolved`

**Описание:**

LinkedIn or trusted professional reviewers are likely the best first external signal path for Meaning Bottleneck/IPaC.

**Evidence / основания:**

LinkedIn was selected as professional resonance and Day 1 first signal path. Trusted reviewers were recommended as soft-start default.

**Unresolved questions / открытые вопросы:**

Is the target audience present on LinkedIn? Should first feedback come from private trusted reviewers, public LinkedIn, or both?

---

### HYP-IPAC-014 — The site should act as a public canon anchor, not a showcase

**Статус:** `partially supported`

**Описание:**

The website should begin as a minimal /meaning-bottleneck anchor that gives external resonance a stable return point, rather than a large portal or marketing showcase.

**Evidence / основания:**

The Site Meaning Bottleneck pack defined site as public canon anchor and produced a skeleton page.

**Unresolved questions / открытые вопросы:**

How much content is enough for the first anchor? Should the page collect interest, direct to LinkedIn, or simply establish canonical framing?

---

### HYP-IPAC-015 — Telegram can function as a living lab pulse without becoming a content treadmill

**Статус:** `unresolved`

**Описание:**

Telegram can hold near-field laboratory rhythm through 1–3 lab notes per week without becoming a daily posting burden.

**Evidence / основания:**

Telegram Lab Pulse pack defines notes, rhythm, boundaries and feedback log, but has not been field tested.

**Unresolved questions / открытые вопросы:**

Will Telegram create useful near-field feedback? Is the audience already present? How to avoid over-posting?

---

### HYP-IPAC-016 — Pinterest can serve as external visual memory and discovery layer

**Статус:** `unresolved`

**Описание:**

Pinterest may help externalize visual seeds and allow discovery through visual memory of concepts such as Meaning Bottleneck, Living Knowledge and Knowledge Clump.

**Evidence / основания:**

Pinterest visual seed pack created five seed cards and metadata, but no external evidence yet.

**Unresolved questions / открытые вопросы:**

Is Pinterest useful for this audience and conceptual category? What visual formats produce meaningful saves or clicks rather than decorative attention?

---

### HYP-IPAC-017 — YouTube should begin as a no-face seed explainer, not a production-heavy channel

**Статус:** `partially supported`

**Описание:**

The first YouTube move should be a lightweight 3–5 minute no-face explainer with voiceover and simple visuals, not a major production effort.

**Evidence / основания:**

YouTube pack defines this approach and explicitly guards against production gravity.

**Unresolved questions / открытые вопросы:**

Should the first video be public, unlisted, or only scripted until other channels produce signals? What minimum production quality is acceptable?

---

### HYP-IPAC-018 — Feedback must be captured as raw evidence before interpretation

**Статус:** `validated`

**Описание:**

Feedback must be preserved in raw form before being interpreted, classified or used to update canon.

**Evidence / основания:**

This rule became central in 89 Feedback Package and 90 71 Review Protocol: Raw first, interpret later.

**Unresolved questions / открытые вопросы:**

What tooling will store feedback in practice: CSV, Obsidian notes, Git, spreadsheets, Project files, or a combined route?

---

### HYP-IPAC-019 — No-signal is diagnostic evidence, not failure

**Статус:** `validated`

**Описание:**

Silence or lack of feedback should be treated as a diagnostic signal about hook, audience, channel, timing, question, exposure or clarity.

**Evidence / основания:**

No-signal protocols were defined in 88–90 and integrated into feedback classification.

**Unresolved questions / открытые вопросы:**

How long is an adequate no-signal window for each channel? What minimum exposure is needed before no-signal has diagnostic value?

---

### HYP-IPAC-020 — 71→72→73 prevents premature canon updates

**Статус:** `validated`

**Описание:**

Routing feedback through 71 Review, 72 Decision and 73 Trace prevents immediate emotional or opportunistic updates to canon.

**Evidence / основания:**

The route is repeatedly established in feedback discipline, 89 package and 90 protocol.

**Unresolved questions / открытые вопросы:**

How lightweight can 71–73 be in real execution without becoming bureaucratic?

---

### HYP-IPAC-021 — 3 ± 2 active items protects execution from overload

**Статус:** `partially supported`

**Описание:**

Limiting the active work zone to 3 ± 2 active items can prevent channel sprawl and cognitive overload during MVI execution.

**Evidence / основания:**

The rule was adopted in 87–88 and Execution Artifact as an operating constraint.

**Unresolved questions / открытые вопросы:**

What counts as an active item in practice? How strictly should the rule be enforced during high-energy creative phases?

---

### HYP-IPAC-022 — New documents should only be created if they close an execution gap

**Статус:** `partially supported`

**Описание:**

After the execution pivot, new artifacts must support execution, not expand architecture for its own sake.

**Evidence / основания:**

This became a core rule after the 79–90 growth phase and was fixed in Execution Pivot and Phase 4.

**Unresolved questions / открытые вопросы:**

How to distinguish a genuine execution gap from architecture temptation? Who decides when a new artifact is necessary?

---

### HYP-IPAC-023 — Mermaid diagrams accelerate understanding and should be core artifacts

**Статус:** `validated`

**Описание:**

Mermaid diagrams and schema-as-code improve grasp of complex project structures and should be treated as engineering artifacts, not decorations.

**Evidence / основания:**

The user repeatedly confirmed that schemes are grasped much faster and requested Mermaid posters; diagrams became central to boot, mentor and lifecycle thinking.

**Unresolved questions / открытые вопросы:**

Which diagrams are essential for boot and which are optional? How should diagrams be versioned with documents?

---

### HYP-IPAC-024 — Obsidian/Canvas can serve as visual front-end for Knowledge Clump dynamics

**Статус:** `partially supported`

**Описание:**

Obsidian and Canvas are likely suitable for visualizing Knowledge Clumps and observing their dynamic relations.

**Evidence / основания:**

The user installed and confirmed Obsidian/Canvas as highly aligned with Knowledge Clump visualization.

**Unresolved questions / открытые вопросы:**

What exact vault structure, Canvas layout and Git sync rules are needed? How much should be automated?

---

### HYP-IPAC-025 — Git/GitHub can function as versioned memory for IPaC

**Статус:** `partially supported`

**Описание:**

Git/GitHub can provide versioned memory, trace, collaboration and change discipline for IPaC artifacts.

**Evidence / основания:**

Git/GitHub were repeatedly selected as core infrastructure with Obsidian, VS Code, Codex and MCP.

**Unresolved questions / открытые вопросы:**

What repository structure and commit conventions should govern knowledge artifacts? How to avoid Git overhead blocking writing?

---

### HYP-IPAC-026 — Codex/VS Code can act as engineering execution layer for IPaC

**Статус:** `partially supported`

**Описание:**

Codex in VS Code can help turn conceptual artifacts into file structures, scripts, websites, automation, checks and operational packages.

**Evidence / основания:**

The user identified VS Code + Codex + Git + Obsidian + MCP as a key technical contour.

**Unresolved questions / открытые вопросы:**

Which tasks should Codex execute first? How to prevent Codex from fixing only part of a problem and stopping before implementation?

---

### HYP-IPAC-027 — MCP can become a connectivity layer for IPaC tools

**Статус:** `unresolved`

**Описание:**

MCP may serve as a protocol/bus for connecting tools, sources and agents within the IPaC operating environment.

**Evidence / основания:**

MCP was identified as one of the four powerful technical elements with VS Code/Codex, Git/GitHub and Obsidian.

**Unresolved questions / открытые вопросы:**

What MCP servers are actually needed? What should be automated first? What security and complexity risks appear?

---

### HYP-IPAC-028 — Project portation is a boot process, not just file upload

**Статус:** `validated`

**Описание:**

Moving IPaC to a new plan/Project requires a boot process with Mentor Layer, core sources, expected boot output and recovery criteria.

**Evidence / основания:**

The portation process was explicitly framed this way, with boot sources, first boot message and verification requirements.

**Unresolved questions / открытые вопросы:**

Will the new Project reliably boot from the package? What source ordering yields the cleanest boot response?

---

### HYP-IPAC-029 — The AI Mentor can mentor subsequent AIs and agents into the canon

**Статус:** `speculative`

**Описание:**

AI can act as a mentor or continuity guide not only for the human user but also for other AIs, agents and project environments.

**Evidence / основания:**

The concept was articulated and packaged as AI Mentor Layer; however, it has not yet been validated across actual new models/agents.

**Unresolved questions / открытые вопросы:**

How much of mentorship transfers via prompt and files? How do different models interpret subject boundaries and execution pivot?

---

### HYP-IPAC-030 — Protein-silicon resonance describes the creative human-AI loop

**Статус:** `speculative`

**Описание:**

The human-AI creative loop can be understood as protein-silicon resonance: human gives living impulse, AI expands and structures, human reacts and redirects.

**Evidence / основания:**

The metaphor accurately described the subjective experience of collaboration and produced productive concepts.

**Unresolved questions / открытые вопросы:**

Should this remain an internal metaphor, or can it become part of public IPaC language? How to avoid pseudo-scientific framing?

---

### HYP-IPAC-031 — Semantic superconductivity is possible in well-designed meaning systems

**Статус:** `speculative`

**Описание:**

A sufficiently well-designed IPaC system might reduce loss and friction in transmitting meaning through complexity.

**Evidence / основания:**

The idea appears in the 'Physics of IGES' / barriers, portals, resonance and semantic superconductivity metaphor.

**Unresolved questions / открытые вопросы:**

Can this be operationalized as measurable reduction of context loss, rework, misunderstanding or boot friction?

---

### HYP-IPAC-032 — Knowledge Clumps can behave like living systems

**Статус:** `speculative`

**Описание:**

Knowledge Clumps may display living-system-like properties: growth, feedback response, forks, emergence, reconfiguration and social interaction.

**Evidence / основания:**

The lifecycle diagrams and living knowledge discussions support the metaphor, but empirical validation is pending.

**Unresolved questions / открытые вопросы:**

What are the operational criteria of 'living'? Which signs distinguish a living Knowledge Clump from a well-organized archive?

---

### HYP-IPAC-033 — Social self-organization can form around a Knowledge Clump

**Статус:** `speculative`

**Описание:**

A Knowledge Clump that enters social circulation may attract feedback, use, discussion, forks and community-level self-organization.

**Evidence / основания:**

The concept aligns with living knowledge circulation and external resonance, but there is no field evidence yet.

**Unresolved questions / открытые вопросы:**

What minimum public signal can trigger community formation? Which channels and topics are most likely to create self-organization?

---

### HYP-IPAC-034 — Trusted reviewers are safer than immediate public launch for first MVI

**Статус:** `unresolved`

**Описание:**

The first external validation may be better done through selected trusted reviewers before public LinkedIn/site release.

**Evidence / основания:**

Phase 4 recommends Trusted reviewers first as default to reduce risk and gather quality signals.

**Unresolved questions / открытые вопросы:**

Who are the right reviewers? How many are enough? What prompt/question should be sent to them?

---

### HYP-IPAC-035 — Meaning Bottleneck is the correct first public hook

**Статус:** `unresolved`

**Описание:**

The first public-facing IPaC signal should be Meaning Bottleneck rather than the full IPaC architecture, Knowledge Clump theory or SOS framing.

**Evidence / основания:**

Meaning Bottleneck was selected across 82–86 as the first channel asset focus.

**Unresolved questions / открытые вопросы:**

Will audiences understand and care? Should the phrase be translated/adapted for different channels?

---

### HYP-IPAC-036 — The book should be the spine of public canon

**Статус:** `partially supported`

**Описание:**

The IPaC book should function as the public canon spine, consolidating formulas, distinctions, examples, feedback and evolving arguments.

**Evidence / основания:**

The book repeatedly appeared as the long-form canon and public architecture backbone.

**Unresolved questions / открытые вопросы:**

When should book writing resume relative to MVI execution? Which field evidence is needed before drafting major chapters?

---

### HYP-IPAC-037 — Public communication should be resonance infrastructure, not ordinary marketing

**Статус:** `partially supported`

**Описание:**

External communications should be designed as a resonance and feedback infrastructure that helps the Knowledge Clump meet social reality.

**Evidence / основания:**

The external contour was reframed as icebreaker and not marketing; the user strongly accepted this framing.

**Unresolved questions / открытые вопросы:**

How to express this publicly without sounding abstract? What metrics should replace ordinary marketing vanity metrics?

---

### HYP-IPAC-038 — The project needs a distinction between mature, preliminary and speculative concepts

**Статус:** `validated`

**Описание:**

Concepts must be classified by maturity to prevent powerful metaphors and hypotheses from being prematurely treated as canon.

**Evidence / основания:**

Phase 2 Concept Artifact explicitly introduced maturity groups and separated mature, preliminary and speculative concepts.

**Unresolved questions / открытые вопросы:**

How often should maturity be reviewed? What evidence promotes a concept from speculative to preliminary or mature?

---

### HYP-IPAC-039 — Need Artifact and Concept Artifact can stabilize portation

**Статус:** `partially supported`

**Описание:**

Extracting Phase 1 Need and Phase 2 Concept artifacts helps a new Project understand the foundation before execution.

**Evidence / основания:**

The portation phase requested and generated these artifacts to support the new plan.

**Unresolved questions / открытые вопросы:**

Will the new Project use these artifacts effectively? Is Phase 3 Hypothesis Registry needed before architecture or execution?

---

### HYP-IPAC-040 — Hypothesis registry is needed before further development

**Статус:** `partially supported`

**Описание:**

A registry of hypotheses prevents confusion between confirmed working rules, partially supported assumptions, unresolved questions and speculative metaphors.

**Evidence / основания:**

The current Phase 3 request explicitly asks for such a registry with statuses, evidence and unresolved questions.

**Unresolved questions / открытые вопросы:**

Which hypotheses should be tested first in Phase 4 MVI execution? How should registry updates be tied to 71–73?

---

### HYP-IPAC-041 — The first execution cycle should produce field evidence, not polished outputs

**Статус:** `validated`

**Описание:**

The goal of the next cycle is to accumulate real experience and evidence, not to perfect all public assets before launch.

**Evidence / основания:**

The execution pivot explicitly states that the next source of knowledge is field experience, not further internal reflection.

**Unresolved questions / открытые вопросы:**

What level of roughness is acceptable for trusted reviewers vs public release?

---

### HYP-IPAC-042 — Architecture can become a way to postpone action

**Статус:** `validated`

**Описание:**

After rapid conceptual growth, further architecture can become a defensive delay mechanism unless constrained by execution needs.

**Evidence / основания:**

This risk was explicitly identified and accepted by the user after documents 79–90.

**Unresolved questions / открытые вопросы:**

What governance rule will stop architecture expansion when it becomes avoidance?

---

## 3. Приоритеты проверки через MVI

В первую очередь через Phase 4 / MVI Execution нужно проверять гипотезы со статусом `unresolved` и наиболее важные `partially supported`:

```text
HYP-IPAC-001 — Meaning Bottleneck as first hook
HYP-IPAC-011 — MVI as correct first validation form
HYP-IPAC-012 — five-channel contour as one system
HYP-IPAC-013 — LinkedIn / trusted reviewers as first resonance path
HYP-IPAC-014 — site as public canon anchor
HYP-IPAC-028 — Project portation as boot process
HYP-IPAC-035 — Meaning Bottleneck as correct first public hook
HYP-IPAC-039 — Need / Concept artifacts as portation stabilizers
```

## 4. Правило обновления реестра

```text
Ни одна гипотеза не должна повышать статус без evidence.
Field feedback проходит через 89 Feedback Package и 90 / 71 Review.
Решение об изменении статуса должно фиксироваться через 72 Decision и 73 Trace.
```

## 5. Статус артефакта

```yaml
artifact_id: PHASE3-HYPOTHESIS-REGISTRY-IPAC-001
artifact_type: hypothesis_registry
version: v0.1
status: accepted-candidate
phase: Phase 3
project: IPaC / Information Production as Code
previous_artifacts:
  - PHASE1-NEED-ARTIFACT-IPAC-001
  - PHASE2-CONCEPT-ARTIFACT-IPAC-001
related_artifact:
  - PHASE4-EXECUTION-ARTIFACT-IPAC-001
next_artifact: PHASE 5 — FIELD EVIDENCE / VALIDATION ARTIFACT
```