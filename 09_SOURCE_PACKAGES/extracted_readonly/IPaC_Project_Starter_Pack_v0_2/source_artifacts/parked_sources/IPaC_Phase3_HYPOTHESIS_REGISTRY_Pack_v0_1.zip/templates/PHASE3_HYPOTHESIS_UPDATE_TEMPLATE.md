# PHASE3_HYPOTHESIS_UPDATE_TEMPLATE.md

# Hypothesis Status Update Template

```yaml
hypothesis_id:
current_status:
proposed_status:
source_feedback_ids:
source_review:
decision_id:
trace_id:
date:
```

## Evidence added

```text

```

## Reason for status change

```text

```

## Remaining unresolved questions

```text

```

## Route

```text
Raw feedback → 89 Feedback Package → 90 / 71 Review → 72 Decision → 73 Trace → Registry update
```
