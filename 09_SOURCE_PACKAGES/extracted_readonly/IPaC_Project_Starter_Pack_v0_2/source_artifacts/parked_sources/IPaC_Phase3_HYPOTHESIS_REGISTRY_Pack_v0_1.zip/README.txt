IPaC Phase 3 — HYPOTHESIS REGISTRY Pack v0.1

Назначение:
Пакет содержит отчуждаемый документ HYPOTHESIS REGISTRY / Реестр гипотез
для проекта IPaC / Information Production as Code.

Документ фиксирует:
- описание каждой гипотезы;
- статус;
- evidence / основания;
- unresolved questions / открытые вопросы;
- приоритеты проверки через MVI.

Статусы:
- validated
- partially supported
- speculative
- contradictory
- unresolved

Как использовать:
1. Открыть docs/PHASE3_HYPOTHESIS_REGISTRY_IPAC.md.
2. Использовать registers/PHASE3_HYPOTHESIS_REGISTRY.csv как рабочий реестр.
3. После field evidence обновлять статусы только через 89 → 90 / 71 → 72 → 73.
4. Использовать unresolved и partially supported гипотезы как вход для Phase 4 / MVI Execution.

Главное правило:
Ни одна гипотеза не должна повышать статус без evidence.
