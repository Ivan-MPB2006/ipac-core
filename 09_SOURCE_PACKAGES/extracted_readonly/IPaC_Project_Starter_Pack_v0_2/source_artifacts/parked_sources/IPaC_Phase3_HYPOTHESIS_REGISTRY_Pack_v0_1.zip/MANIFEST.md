# MANIFEST.md

# IPaC Phase 3 — HYPOTHESIS REGISTRY Pack v0.1

| Путь | Назначение |
|---|---|
| `docs/PHASE3_HYPOTHESIS_REGISTRY_IPAC.md` | основной реестр гипотез |
| `registers/PHASE3_HYPOTHESIS_REGISTRY.csv` | CSV-реестр гипотез |
| `registers/PHASE3_HYPOTHESIS_STATUS_SUMMARY.csv` | сводка статусов |
| `maps/PHASE3_HYPOTHESIS_VALIDATION_FLOW.mmd` | Mermaid-карта проверки гипотез |
| `templates/PHASE3_HYPOTHESIS_UPDATE_TEMPLATE.md` | шаблон обновления гипотезы |
| `status/PHASE3_HYPOTHESIS_REGISTRY_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Главное правило

```text
Ни одна гипотеза не должна повышать статус без evidence.
```
