# MANIFEST.md

# IPaC Phase 3 — Extended HYPOTHESIS REGISTRY ARTIFACT Pack v0.2

| Путь | Назначение |
|---|---|
| `docs/PHASE3_HYPOTHESIS_REGISTRY_EXTENDED_IPAC.md` | основной расширенный реестр гипотез |
| `registers/PHASE3_HYPOTHESIS_REGISTER_EXTENDED.csv` | полный CSV-реестр гипотез |
| `registers/PHASE3_HYPOTHESIS_CATEGORY_SUMMARY.csv` | сводка по категориям |
| `registers/PHASE3_HYPOTHESIS_CONFIDENCE_SUMMARY.csv` | сводка по confidence |
| `registers/PHASE3_HYPOTHESIS_STATUS_SUMMARY.csv` | сводка по статусам |
| `status/PHASE3_HYPOTHESIS_REGISTRY_EXTENDED_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Critical rule

```text
Do not turn desire into validated evidence.
Do not turn execution hypotheses into architecture.
```
