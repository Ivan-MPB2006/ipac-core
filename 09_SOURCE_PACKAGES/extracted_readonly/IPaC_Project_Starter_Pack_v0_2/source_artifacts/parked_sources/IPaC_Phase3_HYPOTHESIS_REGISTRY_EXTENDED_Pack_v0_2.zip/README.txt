IPaC Phase 3 — Extended HYPOTHESIS REGISTRY ARTIFACT Pack v0.2

Назначение:
Расширенный инженерный реестр гипотез IPaC, подготовленный в роли:
- Knowledge Recovery Analyst;
- Research Discipline Consultant.

Пакет НЕ развивает концепт и НЕ формирует execution plan.
Он извлекает гипотезы из предыдущего чата как из архива.

Содержит:
- main markdown artifact;
- hypothesis register CSV;
- confidence summary;
- category summary;
- status JSON;
- README;
- MANIFEST.

Главное правило:
Статус гипотезы не повышается без evidence.
Execution-гипотезы не являются архитектурой.
Спекулятивные гипотезы не являются подтверждённым canon.
