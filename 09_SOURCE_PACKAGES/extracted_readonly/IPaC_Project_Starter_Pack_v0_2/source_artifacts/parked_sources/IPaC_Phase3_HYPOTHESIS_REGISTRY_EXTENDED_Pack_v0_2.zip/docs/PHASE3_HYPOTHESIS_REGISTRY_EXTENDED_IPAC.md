# PHASE 3 — HYPOTHESIS REGISTRY ARTIFACT
# Расширенный реестр гипотез

**Проект:** IPaC / Information Production as Code  
**Роль анализа:** Knowledge Recovery Analyst / Research Discipline Consultant  
**Контур:** Phase 3 / Hypothesis Recovery / Research Discipline / Evidence Governance  
**Тип документа:** отчуждаемый информационный артефакт / инженерный реестр гипотез  
**Версия:** v0.2  
**Статус:** accepted-candidate  
**Дата:** 2026-06-08  

---

## 0. Назначение

Этот документ извлекает гипотезы IPaC из предыдущего чата как из архива. Документ не продолжает обсуждение, не развивает концепт, не проектирует новую архитектуру и не переходит к MVP / execution.

Цель — отделить факты, решения, архитектурные инварианты и гипотезы, а сами гипотезы оформить как инженерный реестр с evidence, assumptions, risks, validation/falsification criteria и confidence level.

## 1. Критические правила

```text
не добавлять новых гипотез;
не улучшать концепт;
не предлагать новую архитектуру;
не переходить к MVP или execution;
отделять факты от гипотез;
отделять гипотезы от решений;
отделять архитектурные гипотезы от execution-гипотез;
не превращать желаемое в подтверждённое;
если гипотеза красивая, но не проверена — speculative;
если гипотеза требует MVP / field test — помечать это явно;
если гипотеза противоречит Phase 1 Need или Phase 4 Architecture Invariants — contradiction.
```

## 2. Сводка

**Всего гипотез:** 33

### 2.1. По категориям

| Категория | Количество |
|---|---:|
| Core hypotheses | 5 |
| Research hypotheses | 6 |
| Architectural hypotheses | 9 |
| Execution hypotheses | 9 |
| Dangerous assumptions | 4 |

### 2.2. По статусам

| Статус | Количество |
|---|---:|
| validated | 14 |
| partially supported | 11 |
| speculative | 4 |
| contradictory | 0 |
| unresolved | 4 |

### 2.3. По confidence level

| Confidence level | Количество |
|---|---:|
| medium-high | 2 |
| medium | 9 |
| high | 14 |
| medium-low | 3 |
| low-medium | 3 |
| low | 2 |

### 2.4. Dangerous assumptions

**Dangerous assumptions marked:** 15

---

## 3. A. Core hypotheses

- **HYP-IPAC-001** — Output became cheap; meaning became the bottleneck (`partially supported`, confidence: `medium-high`)
- **HYP-IPAC-003** — Knowledge Clumps are more than document collections (`validated`, confidence: `high`)
- **HYP-IPAC-004** — Living knowledge requires use, feedback and rebuild (`validated`, confidence: `high`)
- **HYP-IPAC-009** — Intersubjectivity improves human-AI creative engineering (`partially supported`, confidence: `medium`)
- **HYP-IPAC-010** — Human subjecthood must remain non-transferable (`validated`, confidence: `high`)

## 4. B. Architectural hypotheses

- **HYP-IPAC-005** — Living knowledge circulation is a better system boundary than document workflow (`validated`, confidence: `high`)
- **HYP-IPAC-006** — IPaC can be understood as a specialized operating system (`partially supported`, confidence: `medium-high`)
- **HYP-IPAC-007** — Bootability is essential for continuity (`validated`, confidence: `high`)
- **HYP-IPAC-008** — AI Mentor Layer can preserve intersubjective collaboration (`partially supported`, confidence: `medium`)
- **HYP-IPAC-013** — Review-before-canon prevents premature changes (`validated`, confidence: `high`)
- **HYP-IPAC-018** — Specific publication channels are not architecture (`validated`, confidence: `high`)
- **HYP-IPAC-019** — Artifacts must be bootable and portable (`validated`, confidence: `high`)
- **HYP-IPAC-020** — Mermaid diagrams are core comprehension artifacts (`validated`, confidence: `high`)
- **HYP-IPAC-033** — Mature/preliminary/speculative separation is necessary for architecture discipline (`validated`, confidence: `high`)

## 5. C. Research hypotheses

- **HYP-IPAC-002** — Organizations need information production engineering (`partially supported`, confidence: `medium`)
- **HYP-IPAC-011** — Feedback must be captured as raw evidence before interpretation (`validated`, confidence: `high`)
- **HYP-IPAC-012** — No-signal is diagnostic evidence (`validated`, confidence: `high`)
- **HYP-IPAC-025** — Hypothesis registry prevents confusion between evidence and desire (`validated`, confidence: `high`)
- **HYP-IPAC-026** — Need and Concept artifacts stabilize portation (`partially supported`, confidence: `medium`)
- **HYP-IPAC-031** — Social self-organization can form around a Knowledge Clump (`speculative`, confidence: `low`)

## 6. D. Execution hypotheses

Execution hypotheses are not architecture. They require field test / MVP / MVI evidence before promotion.

- **HYP-IPAC-014** — MVI is the correct first external validation form (`partially supported`, confidence: `medium`)
- **HYP-IPAC-015** — Five-channel contour can operate as one resonance system (`unresolved`, confidence: `medium-low`)
- **HYP-IPAC-016** — Trusted reviewers may be the safest first validation path (`unresolved`, confidence: `medium-low`)
- **HYP-IPAC-017** — Meaning Bottleneck is the right first public hook (`unresolved`, confidence: `medium-low`)
- **HYP-IPAC-021** — Obsidian/Canvas can support Knowledge Clump dynamics (`partially supported`, confidence: `medium`)
- **HYP-IPAC-022** — Git/GitHub can function as versioned knowledge memory (`partially supported`, confidence: `medium`)
- **HYP-IPAC-023** — Codex/VS Code can serve as engineering execution layer (`partially supported`, confidence: `medium`)
- **HYP-IPAC-024** — MCP can become a connectivity layer (`unresolved`, confidence: `low-medium`)
- **HYP-IPAC-032** — The book should become a public canon spine (`partially supported`, confidence: `medium`)

## 7. E. Dangerous assumptions

Dangerous assumptions are hypotheses that are especially attractive, generative or strategically important, but can distort the project if treated as confirmed too early.

- **HYP-IPAC-002** — Organizations need information production engineering (`partially supported`, category: Research hypotheses, confidence: `medium`)
- **HYP-IPAC-006** — IPaC can be understood as a specialized operating system (`partially supported`, category: Architectural hypotheses, confidence: `medium-high`)
- **HYP-IPAC-008** — AI Mentor Layer can preserve intersubjective collaboration (`partially supported`, category: Architectural hypotheses, confidence: `medium`)
- **HYP-IPAC-009** — Intersubjectivity improves human-AI creative engineering (`partially supported`, category: Core hypotheses, confidence: `medium`)
- **HYP-IPAC-014** — MVI is the correct first external validation form (`partially supported`, category: Execution hypotheses, confidence: `medium`)
- **HYP-IPAC-015** — Five-channel contour can operate as one resonance system (`unresolved`, category: Execution hypotheses, confidence: `medium-low`)
- **HYP-IPAC-017** — Meaning Bottleneck is the right first public hook (`unresolved`, category: Execution hypotheses, confidence: `medium-low`)
- **HYP-IPAC-023** — Codex/VS Code can serve as engineering execution layer (`partially supported`, category: Execution hypotheses, confidence: `medium`)
- **HYP-IPAC-024** — MCP can become a connectivity layer (`unresolved`, category: Execution hypotheses, confidence: `low-medium`)
- **HYP-IPAC-027** — Execution expansion can postpone action (`validated`, category: Dangerous assumptions, confidence: `high`)
- **HYP-IPAC-028** — Protein-silicon resonance describes the collaboration loop (`speculative`, category: Dangerous assumptions, confidence: `low-medium`)
- **HYP-IPAC-029** — Semantic superconductivity is possible in well-designed meaning systems (`speculative`, category: Dangerous assumptions, confidence: `low`)
- **HYP-IPAC-030** — Knowledge Clumps can behave like living systems (`speculative`, category: Dangerous assumptions, confidence: `low-medium`)
- **HYP-IPAC-031** — Social self-organization can form around a Knowledge Clump (`speculative`, category: Research hypotheses, confidence: `low`)
- **HYP-IPAC-032** — The book should become a public canon spine (`partially supported`, category: Execution hypotheses, confidence: `medium`)

---

## 8. Detailed hypothesis registry

### HYP-IPAC-001 — Output became cheap; meaning became the bottleneck

**Category:** Core hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium-high`  
**Dangerous assumption:** `no`

**Формулировка:**

AI lowers the cost of producing outputs, but does not automatically solve meaning, context, decision quality or actionability.

**К какой потребности относится:**

Phase 1 need: make living meaning manageable, portable and executable knowledge.

**К какому архитектурному инварианту относится:**

AINV-IPAC-001, AINV-IPAC-002, AINV-IPAC-011

**Evidence / основания:**

The formula 'AI made output cheap. Now meaning is the bottleneck' became a repeated organizing formula across the dialogue and concept artifacts.

**Assumptions / предположения:**

External audiences will also recognize output abundance as insufficient without meaning production discipline.

**Risks / риски:**

May be too abstract or too broad for first public understanding.

**What would validate it / что могло бы подтвердить:**

Target readers independently recognize the bottleneck and provide concrete cases or objections that map to meaning production.

**What would falsify it / что могло бы опровергнуть:**

Target readers understand AI-output abundance but do not see meaning as the central bottleneck, or consistently identify a different bottleneck.

---

### HYP-IPAC-002 — Organizations need information production engineering

**Category:** Research hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium`  
**Dangerous assumption:** `yes`

**Формулировка:**

Organizations need an engineering discipline for producing, validating, updating and reusing knowledge outputs, not only AI-assisted drafting.

**К какой потребности относится:**

Need for a system of living knowledge circulation and engineering-managed information production.

**К какому архитектурному инварианту относится:**

AINV-IPAC-001, AINV-IPAC-018, AINV-IPAC-025

**Evidence / основания:**

The discussion repeatedly contrasted IPaC with ordinary documents, content operations, knowledge management and project management.

**Assumptions / предположения:**

Organizations will feel the pain strongly enough to seek a new discipline or operating model.

**Risks / риски:**

May overlap with existing fields and be perceived as repackaging knowledge management or content operations.

**What would validate it / что могло бы подтвердить:**

Executives or operators identify the same gap and ask for a system beyond AI writing and knowledge storage.

**What would falsify it / что могло бы опровергнуть:**

Existing knowledge/content operations frameworks already satisfy the need in real organizational contexts.

---

### HYP-IPAC-003 — Knowledge Clumps are more than document collections

**Category:** Core hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

A Knowledge Clump is a structured and emergent knowledge formation containing artifacts, context, decisions, trace, feedback and implicit meaning.

**К какой потребности относится:**

Need to preserve living meaning rather than just files.

**К какому архитектурному инварианту относится:**

AINV-IPAC-002, AINV-IPAC-007, AINV-IPAC-014

**Evidence / основания:**

The concept was repeatedly defined, used in artifacts and contrasted with folders, archives and frames.

**Assumptions / предположения:**

The distinction remains meaningful when moved into tooling and external explanation.

**Risks / риски:**

Could become vague if metadata and lifecycle requirements are not operationalized.

**What would validate it / что могло бы подтвердить:**

Another Project or agent can use the concept to reconstruct context and preserve relations better than a document folder.

**What would falsify it / что могло бы опровергнуть:**

The concept collapses into ordinary archive/folder behavior in practice.

---

### HYP-IPAC-004 — Living knowledge requires use, feedback and rebuild

**Category:** Core hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

Knowledge becomes living when it circulates through use, receives feedback, is reviewed, and can update canon and trace.

**К какой потребности относится:**

Need for a system of living knowledge circulation.

**К какому архитектурному инварианту относится:**

AINV-IPAC-002, AINV-IPAC-019, AINV-IPAC-025

**Evidence / основания:**

Living Knowledge and knowledge lifecycle diagrams consistently include use, feedback, review and rebuild.

**Assumptions / предположения:**

Feedback and trace are sufficient minimum mechanisms for liveliness in the IPaC sense.

**Risks / риски:**

Could be overextended into a quasi-biological metaphor if not kept operational.

**What would validate it / что могло бы подтвердить:**

Reviewed feedback changes artifacts, decisions or projections while preserving trace.

**What would falsify it / что могло бы опровергнуть:**

Knowledge artifacts can remain equally useful without feedback/review/trace loops.

---

### HYP-IPAC-005 — Living knowledge circulation is a better system boundary than document workflow

**Category:** Architectural hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

IPaC should be bounded as a system of living knowledge circulation, not document workflow.

**К какой потребности относится:**

Need to avoid reducing the project to document management.

**К какому архитектурному инварианту относится:**

AINV-IPAC-001, AINV-IPAC-002

**Evidence / основания:**

The user explicitly rejected document workflow as too narrow; Phase 1 and Phase 4 stabilize the boundary.

**Assumptions / предположения:**

The living knowledge boundary can be communicated without becoming too abstract.

**Risks / риски:**

Public wording may sound less familiar than document workflow or knowledge management.

**What would validate it / что могло бы подтвердить:**

The boundary helps new agents and readers avoid wrong reductions.

**What would falsify it / что могло бы опровергнуть:**

Users consistently need document workflow framing to understand or use the system.

---

### HYP-IPAC-006 — IPaC can be understood as a specialized operating system

**Category:** Architectural hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium-high`  
**Dangerous assumption:** `yes`

**Формулировка:**

IPaC can be framed internally as a specialized operating system for information production as code.

**К какой потребности относится:**

Need for bootability, runtime, status, governance and continuity.

**К какому архитектурному инварианту относится:**

AINV-IPAC-018, AINV-IPAC-020, AINV-IPAC-023

**Evidence / основания:**

The SOS metaphor generated productive internal structures: boot, runtime, dashboard, status, recovery and mentor layer.

**Assumptions / предположения:**

The operating-system metaphor clarifies rather than distorts the project.

**Risks / риски:**

May be too heavy or misleading for external audiences.

**What would validate it / что могло бы подтвердить:**

The metaphor helps new Project boot and helps agents understand boundaries and state.

**What would falsify it / что могло бы опровергнуть:**

The metaphor causes confusion, overengineering or expectation of actual software OS functionality.

---

### HYP-IPAC-007 — Bootability is essential for continuity

**Category:** Architectural hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

A project cannot be reliably moved across plans, Projects or agents by files alone; it needs boot sources, instructions, status recovery and recovery commands.

**К какой потребности относится:**

Need to port living knowledge without losing context.

**К какому архитектурному инварианту относится:**

AINV-IPAC-018, AINV-IPAC-020, AINV-IPAC-031

**Evidence / основания:**

Portation produced Mentor Layer, Boot Protocol, First Boot Message and recovery criteria.

**Assumptions / предположения:**

A disciplined boot pack can restore enough context for continuation.

**Risks / риски:**

Boot packs may become too large or stale.

**What would validate it / что могло бы подтвердить:**

A new Project produces correct current_status / execution_mode / one_next_action from the boot package.

**What would falsify it / что могло бы опровергнуть:**

New Project repeatedly starts from zero or misreads status despite boot sources.

---

### HYP-IPAC-008 — AI Mentor Layer can preserve intersubjective collaboration

**Category:** Architectural hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium`  
**Dangerous assumption:** `yes`

**Формулировка:**

An AI Mentor Layer can transmit the mode of work: intersubjectivity, anti-generic behavior, boot, handoff, execution pivot and role boundaries.

**К какой потребности относится:**

Need to transfer not only files but interaction mode.

**К какому архитектурному инварианту относится:**

AINV-IPAC-004, AINV-IPAC-006, AINV-IPAC-013

**Evidence / основания:**

AI Mentor Layer was defined, packaged and accepted as a continuity layer.

**Assumptions / предположения:**

A prompt and source package can preserve interaction mode across environments.

**Risks / риски:**

Interaction quality may depend on accumulated conversation history and not fully transfer.

**What would validate it / что могло бы подтвердить:**

New Project enters the intended role, avoids generic answers and maintains human-AI separation.

**What would falsify it / что могло бы опровергнуть:**

New Project remains generic or becomes directive despite Mentor Layer.

---

### HYP-IPAC-009 — Intersubjectivity improves human-AI creative engineering

**Category:** Core hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium`  
**Dangerous assumption:** `yes`

**Формулировка:**

The most productive mode is creative intersubjectivity: human provides living intention, AI provides structure and operationalization.

**К какой потребности относится:**

Need to preserve living human sense while making it operational.

**К какому архитектурному инварианту относится:**

AINV-IPAC-013, AINV-IPAC-028, AINV-IPAC-029

**Evidence / основания:**

The dialogue produced coherent artifacts, schemes and decisions through this mode, and the user confirmed the mode as valuable.

**Assumptions / предположения:**

This mode is reproducible beyond this specific chat.

**Risks / риски:**

May become personality-dependent or prompt-dependent.

**What would validate it / что могло бы подтвердить:**

New Project or another AI reproduces the constructive collaboration pattern using the Mentor Layer.

**What would falsify it / что могло бы опровергнуть:**

Other environments cannot reproduce it and default to command-response or generic consulting.

---

### HYP-IPAC-010 — Human subjecthood must remain non-transferable

**Category:** Core hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

AI can guide methodology, but the human must retain intent, authorship, strategic judgement and final acceptance.

**К какой потребности относится:**

Need to protect the living source of meaning.

**К какому архитектурному инварианту относится:**

AINV-IPAC-004, AINV-IPAC-028, AINV-IPAC-029

**Evidence / основания:**

The boundary was explicitly formulated in the AI Mentor Layer and Phase 4 invariants.

**Assumptions / предположения:**

Clear instructions can enforce this boundary in multi-agent workflows.

**Risks / риски:**

As agents become more autonomous, role drift can occur.

**What would validate it / что могло бы подтвердить:**

Agents consistently ask for human decisions where meaning/strategy is involved.

**What would falsify it / что могло бы опровергнуть:**

Agents start making strategic canon decisions or appropriating authorship.

---

### HYP-IPAC-011 — Feedback must be captured as raw evidence before interpretation

**Category:** Research hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

Feedback must be preserved in raw form before interpretation, classification or canon impact.

**К какой потребности относится:**

Need for research discipline and reliable learning from environment.

**К какому архитектурному инварианту относится:**

AINV-IPAC-011, AINV-IPAC-015, AINV-IPAC-019

**Evidence / основания:**

Repeated rule: Raw first. Interpret later. Embedded in feedback discipline.

**Assumptions / предположения:**

Raw capture is feasible in ordinary work without excessive overhead.

**Risks / риски:**

Over-capture may slow execution.

**What would validate it / что могло бы подтвердить:**

Feedback entries can be traced from raw source to review findings and decisions.

**What would falsify it / что могло бы опровергнуть:**

Raw capture proves impractical or unnecessary for useful learning.

---

### HYP-IPAC-012 — No-signal is diagnostic evidence

**Category:** Research hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

Silence or weak response should be treated as diagnostic evidence, not failure.

**К какой потребности относится:**

Need to avoid emotional or premature interpretation of external response.

**К какому архитектурному инварианту относится:**

AINV-IPAC-011, AINV-IPAC-019, AINV-IPAC-024

**Evidence / основания:**

No-signal protocols were defined and repeatedly linked to hook/audience/channel/timing diagnosis.

**Assumptions / предположения:**

Exposure and context can be recorded enough to make no-signal meaningful.

**Risks / риски:**

Silence may be overinterpreted without sufficient exposure.

**What would validate it / что могло бы подтвердить:**

No-signal analysis improves next test design.

**What would falsify it / что могло бы опровергнуть:**

No-signal records lack enough context and do not guide any useful revision.

---

### HYP-IPAC-013 — Review-before-canon prevents premature changes

**Category:** Architectural hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

Routing feedback through review and decision before canon update prevents opportunistic or emotional changes.

**К какой потребности относится:**

Need for governance of living knowledge evolution.

**К какому архитектурному инварианту относится:**

AINV-IPAC-015, AINV-IPAC-021, AINV-IPAC-024

**Evidence / основания:**

Established as a mature governance invariant: no canon update without review.

**Assumptions / предположения:**

Review can be lightweight enough not to block learning.

**Risks / риски:**

If too heavy, review discipline can become bureaucracy.

**What would validate it / что могло бы подтвердить:**

Reviewed changes improve traceability without slowing work excessively.

**What would falsify it / что могло бы опровергнуть:**

The route is consistently bypassed because it is too heavy or unhelpful.

---

### HYP-IPAC-014 — MVI is the correct first external validation form

**Category:** Execution hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium`  
**Dangerous assumption:** `yes`

**Формулировка:**

The first field validation should be a Minimum Viable Icebreaker rather than full launch or complete public methodology release.

**К какой потребности относится:**

Need to test living knowledge in environment without overbuilding.

**К какому архитектурному инварианту относится:**

AINV-IPAC-023, AINV-IPAC-033, AINV-IPAC-034

**Evidence / основания:**

MVI emerged as execution pivot and was operationalized, but Phase 4 invariants now classify it as execution candidate, not architecture.

**Assumptions / предположения:**

A minimal external cycle can generate useful evidence.

**Risks / риски:**

MVI may be too small to produce meaningful signals, or too complex if five channels are activated.

**What would validate it / что могло бы подтвердить:**

First MVI produces raw feedback/no-signal evidence sufficient for review.

**What would falsify it / что могло бы опровергнуть:**

MVI produces no usable evidence despite adequate exposure and review.

---

### HYP-IPAC-015 — Five-channel contour can operate as one resonance system

**Category:** Execution hypotheses  
**Status:** `unresolved`  
**Confidence level:** `medium-low`  
**Dangerous assumption:** `yes`

**Формулировка:**

Multiple external channels can function as distinct projections of one Knowledge Clump and one feedback loop.

**К какой потребности относится:**

Need to connect external communication back to living knowledge rather than isolated marketing.

**К какому архитектурному инварианту относится:**

AINV-IPAC-012, AINV-IPAC-033

**Evidence / основания:**

The five-channel contour was designed and integrated, but Phase 4 invariants explicitly classify specific channels as execution candidates.

**Assumptions / предположения:**

Channels can be coordinated without overload.

**Risks / риски:**

Channel sprawl; execution overload; confusion between architecture and publication tactics.

**What would validate it / что могло бы подтвердить:**

Coordinated channels return distinguishable but integrable feedback into the same review route.

**What would falsify it / что могло бы опровергнуть:**

Channels fragment attention and produce disconnected tasks rather than a unified knowledge loop.

---

### HYP-IPAC-016 — Trusted reviewers may be the safest first validation path

**Category:** Execution hypotheses  
**Status:** `unresolved`  
**Confidence level:** `medium-low`  
**Dangerous assumption:** `no`

**Формулировка:**

The first validation may be better through selected trusted reviewers before public release.

**К какой потребности относится:**

Need for low-risk first contact with environment.

**К какому архитектурному инварианту относится:**

AINV-IPAC-012, AINV-IPAC-019, AINV-IPAC-023

**Evidence / основания:**

Trusted reviewers first was recommended as default in prior execution framing.

**Assumptions / предположения:**

Trusted reviewers can provide higher-quality signals than early public noise.

**Risks / риски:**

Reviewer sample may be biased and not represent the intended audience.

**What would validate it / что могло бы подтвердить:**

Reviewers provide concrete questions, objections or cases that improve the next projection.

**What would falsify it / что могло бы опровергнуть:**

Reviewer feedback is too polite, vague or irrelevant to guide the project.

---

### HYP-IPAC-017 — Meaning Bottleneck is the right first public hook

**Category:** Execution hypotheses  
**Status:** `unresolved`  
**Confidence level:** `medium-low`  
**Dangerous assumption:** `yes`

**Формулировка:**

The first external hook should be Meaning Bottleneck rather than full IPaC architecture or Knowledge Clump theory.

**К какой потребности относится:**

Need to make the concept accessible in first contact.

**К какому архитектурному инварианту относится:**

AINV-IPAC-012, AINV-IPAC-033

**Evidence / основания:**

Meaning Bottleneck was repeatedly selected as first asset focus, but not yet externally validated.

**Assumptions / предположения:**

The phrase is understandable and strong enough to invite response.

**Risks / риски:**

May be perceived as abstract or unclear.

**What would validate it / что могло бы подтвердить:**

Readers understand the phrase and provide examples, questions or interest.

**What would falsify it / что могло бы опровергнуть:**

Readers consistently fail to understand or care about the phrase.

---

### HYP-IPAC-018 — Specific publication channels are not architecture

**Category:** Architectural hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

Specific channels and launch mechanics are execution candidates, not architectural invariants.

**К какой потребности относится:**

Need to protect architecture from tactical overfitting.

**К какому архитектурному инварианту относится:**

AINV-IPAC-003, AINV-IPAC-023, AINV-IPAC-033, AINV-IPAC-034

**Evidence / основания:**

The Phase 4 correction explicitly states not to discuss LinkedIn, Telegram, site anchor, dashboard, feedback package, 71/72/73 unless they are architecture invariants.

**Assumptions / предположения:**

The generic invariant can be expressed as projection/use/feedback without naming channels.

**Risks / риски:**

Execution documents may continue to leak into architecture.

**What would validate it / что могло бы подтвердить:**

Architecture artifact remains stable even if channels change.

**What would falsify it / что могло бы опровергнуть:**

Changing channels breaks core architecture, implying channels were part of architecture.

---

### HYP-IPAC-019 — Artifacts must be bootable and portable

**Category:** Architectural hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

Every serious artifact should include enough orientation to be portable: README, MANIFEST, status, registers and primary documents.

**К какой потребности относится:**

Need to move knowledge across environments without losing context.

**К какому архитектурному инварианту относится:**

AINV-IPAC-018, AINV-IPAC-020, AINV-IPAC-026

**Evidence / основания:**

All major packages were structured this way and portation depended on it.

**Assumptions / предположения:**

The orientation layers remain useful and not excessive.

**Risks / риски:**

Packaging overhead may become too high.

**What would validate it / что могло бы подтвердить:**

New Project/agent can use the package without prior hidden context.

**What would falsify it / что могло бы опровергнуть:**

Packages remain incomprehensible or too cumbersome despite orientation layers.

---

### HYP-IPAC-020 — Mermaid diagrams are core comprehension artifacts

**Category:** Architectural hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

Mermaid diagrams accelerate comprehension and should be treated as working artifacts, not decoration.

**К какой потребности относится:**

Need to make complex relationships graspable and portable.

**К какому архитектурному инварианту относится:**

AINV-IPAC-008, AINV-IPAC-017, AINV-IPAC-018

**Evidence / основания:**

The user repeatedly confirmed schemes are understood faster and requested Mermaid posters.

**Assumptions / предположения:**

Mermaid remains compatible with Obsidian/Git/LLM workflows.

**Risks / риски:**

Diagrams may become outdated if not versioned with text.

**What would validate it / что могло бы подтвердить:**

Diagrams help new Project/agent recover structure faster than prose alone.

**What would falsify it / что могло бы опровергнуть:**

Diagrams introduce confusion or drift from the text canon.

---

### HYP-IPAC-021 — Obsidian/Canvas can support Knowledge Clump dynamics

**Category:** Execution hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium`  
**Dangerous assumption:** `no`

**Формулировка:**

Obsidian and Canvas can serve as visual front-end for Knowledge Clumps and their dynamic relations.

**К какой потребности относится:**

Need to see relations, not only read documents.

**К какому архитектурному инварианту относится:**

AINV-IPAC-008, AINV-IPAC-010, AINV-IPAC-026

**Evidence / основания:**

User installed and confirmed Obsidian/Canvas as aligned with Knowledge Clump visualization.

**Assumptions / предположения:**

The tool can scale with project complexity.

**Risks / риски:**

Visual layer may become manual overhead or another archive.

**What would validate it / что могло бы подтвердить:**

Canvas improves navigation, trace and conceptual recall in actual work.

**What would falsify it / что могло бы опровергнуть:**

Obsidian/Canvas becomes decorative or unused.

---

### HYP-IPAC-022 — Git/GitHub can function as versioned knowledge memory

**Category:** Execution hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium`  
**Dangerous assumption:** `no`

**Формулировка:**

Git/GitHub can provide versioned memory, trace, collaboration and change discipline for IPaC artifacts.

**К какой потребности относится:**

Need for traceable knowledge evolution.

**К какому архитектурному инварианту относится:**

AINV-IPAC-010, AINV-IPAC-016, AINV-IPAC-026

**Evidence / основания:**

Git/GitHub were repeatedly selected as infrastructure with Obsidian, VS Code, Codex and MCP.

**Assumptions / предположения:**

Git conventions can be made usable for knowledge work.

**Risks / риски:**

Git overhead may block writing or overwhelm non-technical use.

**What would validate it / что могло бы подтвердить:**

Git trace helps recover decisions and changes without slowing work significantly.

**What would falsify it / что могло бы опровергнуть:**

Git is too burdensome or does not add meaningful trace value.

---

### HYP-IPAC-023 — Codex/VS Code can serve as engineering execution layer

**Category:** Execution hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium`  
**Dangerous assumption:** `yes`

**Формулировка:**

Codex in VS Code can turn conceptual artifacts into file structures, scripts, websites, automation and checks.

**К какой потребности относится:**

Need to move from knowledge artifacts to operational implementation.

**К какому архитектурному инварианту относится:**

AINV-IPAC-008, AINV-IPAC-018, AINV-IPAC-023

**Evidence / основания:**

VS Code + Codex + Git + Obsidian + MCP were identified as technical contour.

**Assumptions / предположения:**

Codex can execute methodically under clear prompts and guardrails.

**Risks / риски:**

Agent may diagnose but not finish, or implement partial fixes.

**What would validate it / что могло бы подтвердить:**

Codex produces controlled, reviewable artifacts consistent with the canon.

**What would falsify it / что могло бы опровергнуть:**

Codex repeatedly creates drift, partial work or unreviewable changes.

---

### HYP-IPAC-024 — MCP can become a connectivity layer

**Category:** Execution hypotheses  
**Status:** `unresolved`  
**Confidence level:** `low-medium`  
**Dangerous assumption:** `yes`

**Формулировка:**

MCP may serve as a connection layer between tools, sources and agents in the IPaC environment.

**К какой потребности относится:**

Need for cross-tool continuity and automation.

**К какому архитектурному инварианту относится:**

AINV-IPAC-020, AINV-IPAC-023

**Evidence / основания:**

MCP was named among the powerful technological elements but not yet validated in the IPaC setup.

**Assumptions / предположения:**

MCP adds more continuity than complexity.

**Risks / риски:**

Security, complexity and premature automation.

**What would validate it / что могло бы подтвердить:**

A concrete MCP use case improves handoff, source access or trace without creating fragility.

**What would falsify it / что могло бы опровергнуть:**

MCP creates more maintenance burden than value at current stage.

---

### HYP-IPAC-025 — Hypothesis registry prevents confusion between evidence and desire

**Category:** Research hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

A hypothesis registry helps distinguish validated rules, partially supported assumptions, unresolved questions and speculative concepts.

**К какой потребности относится:**

Need for research discipline.

**К какому архитектурному инварианту относится:**

AINV-IPAC-022, AINV-IPAC-024

**Evidence / основания:**

The Phase 3 request and artifact explicitly introduce hypothesis status discipline.

**Assumptions / предположения:**

The registry will be updated after evidence, not merely created once.

**Risks / риски:**

Registry may become stale if not tied to review/trace.

**What would validate it / что могло бы подтвердить:**

Field evidence results in status updates through the defined route.

**What would falsify it / что могло бы опровергнуть:**

Registry is not used or statuses drift without evidence.

---

### HYP-IPAC-026 — Need and Concept artifacts stabilize portation

**Category:** Research hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium`  
**Dangerous assumption:** `no`

**Формулировка:**

Extracted Need and Concept artifacts help new Project understand the foundation before action or architecture.

**К какой потребности относится:**

Need for bootable conceptual continuity.

**К какому архитектурному инварианту относится:**

AINV-IPAC-018, AINV-IPAC-020, AINV-IPAC-026

**Evidence / основания:**

The portation phase produced Phase 1 and Phase 2 as foundational artifacts.

**Assumptions / предположения:**

New Project will read and use these artifacts effectively.

**Risks / риски:**

Too many foundation files may slow boot.

**What would validate it / что могло бы подтвердить:**

New Project correctly reconstructs need/concept without starting from zero.

**What would falsify it / что могло бы опровергнуть:**

New Project ignores or misreads these artifacts.

---

### HYP-IPAC-027 — Execution expansion can postpone action

**Category:** Dangerous assumptions  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `yes`

**Формулировка:**

Further architecture or artifact production can become a way to postpone field contact unless constrained by execution need and invariant separation.

**К какой потребности относится:**

Need to avoid self-referential design growth.

**К какому архитектурному инварианту относится:**

AINV-IPAC-003, AINV-IPAC-023, AINV-IPAC-032

**Evidence / основания:**

After the growth phase, user explicitly accepted the need to shift from expansion to field experience; Phase 4 correction reinforces separation.

**Assumptions / предположения:**

Awareness plus constraints can prevent postponement.

**Risks / риски:**

The system keeps producing meta-artifacts rather than testing hypotheses.

**What would validate it / что могло бы подтвердить:**

The project moves to evidence-producing actions after the recovery artifacts.

**What would falsify it / что могло бы опровергнуть:**

The project continues generating artifacts without field evidence.

---

### HYP-IPAC-028 — Protein-silicon resonance describes the collaboration loop

**Category:** Dangerous assumptions  
**Status:** `speculative`  
**Confidence level:** `low-medium`  
**Dangerous assumption:** `yes`

**Формулировка:**

Human and AI form a productive resonance: human impulse plus AI structural expansion plus human redirection.

**К какой потребности относится:**

Need to name the felt mode of intersubjective collaboration.

**К какому архитектурному инварианту относится:**

AINV-IPAC-013, AINV-IPAC-030

**Evidence / основания:**

The metaphor was meaningful in the dialogue and helped articulate intersubjective dynamics.

**Assumptions / предположения:**

The metaphor clarifies without becoming pseudo-scientific.

**Risks / риски:**

Can sound pseudo-scientific or distract from operational architecture.

**What would validate it / что могло бы подтвердить:**

It helps internal orientation while staying clearly metaphorical.

**What would falsify it / что могло бы опровергнуть:**

It confuses readers or is mistaken for scientific claim.

---

### HYP-IPAC-029 — Semantic superconductivity is possible in well-designed meaning systems

**Category:** Dangerous assumptions  
**Status:** `speculative`  
**Confidence level:** `low`  
**Dangerous assumption:** `yes`

**Формулировка:**

A system may reduce loss and friction in passing meaning through complexity.

**К какой потребности относится:**

Need to preserve meaning across complex transformations.

**К какому архитектурному инварианту относится:**

AINV-IPAC-025, AINV-IPAC-027, AINV-IPAC-030

**Evidence / основания:**

The metaphor appears in the physics-of-meaning line: barriers, portals, resonances, superconductivity.

**Assumptions / предположения:**

Meaning-loss reduction can eventually be operationalized.

**Risks / риски:**

Highly attractive metaphor may be prematurely canonized.

**What would validate it / что могло бы подтвердить:**

Operational metrics show reduced context loss, rework, misunderstanding or boot friction.

**What would falsify it / что могло бы опровергнуть:**

The metaphor cannot be translated into operational criteria.

---

### HYP-IPAC-030 — Knowledge Clumps can behave like living systems

**Category:** Dangerous assumptions  
**Status:** `speculative`  
**Confidence level:** `low-medium`  
**Dangerous assumption:** `yes`

**Формулировка:**

Knowledge Clumps may display living-system-like properties: growth, feedback response, forks, emergence and reconfiguration.

**К какой потребности относится:**

Need to understand living knowledge beyond static artifacts.

**К какому архитектурному инварианту относится:**

AINV-IPAC-002, AINV-IPAC-025, AINV-IPAC-027

**Evidence / основания:**

Lifecycle diagrams and living knowledge discussions support the metaphor.

**Assumptions / предположения:**

Living-system language can be operationalized without mystification.

**Risks / риски:**

Can blur metaphor and system design.

**What would validate it / что могло бы подтвердить:**

Operational signs such as reviewed feedback-driven change, forks and traceable adaptation appear.

**What would falsify it / что могло бы опровергнуть:**

The clump behaves only as a static archive despite the language.

---

### HYP-IPAC-031 — Social self-organization can form around a Knowledge Clump

**Category:** Research hypotheses  
**Status:** `speculative`  
**Confidence level:** `low`  
**Dangerous assumption:** `yes`

**Формулировка:**

A Knowledge Clump entering social circulation may attract feedback, use, discussion, forks and community-level self-organization.

**К какой потребности относится:**

Need for living knowledge to interact with social environment.

**К какому архитектурному инварианту относится:**

AINV-IPAC-012, AINV-IPAC-019, AINV-IPAC-025

**Evidence / основания:**

Discussed as a possible result of social resonance and living knowledge circulation.

**Assumptions / предположения:**

The external field can self-organize around useful knowledge, not just consume content.

**Risks / риски:**

Long-term social effect may be overestimated.

**What would validate it / что могло бы подтвердить:**

External participants begin applying, discussing, forking or contributing to the Knowledge Clump.

**What would falsify it / что могло бы опровергнуть:**

External contact produces only passive consumption or no sustained engagement.

---

### HYP-IPAC-032 — The book should become a public canon spine

**Category:** Execution hypotheses  
**Status:** `partially supported`  
**Confidence level:** `medium`  
**Dangerous assumption:** `yes`

**Формулировка:**

The IPaC book can serve as a long-form public canon spine for the concept, evidence and evolving argument.

**К какой потребности относится:**

Need for coherent public articulation.

**К какому архитектурному инварианту относится:**

AINV-IPAC-008, AINV-IPAC-009, AINV-IPAC-012

**Evidence / основания:**

The book repeatedly appeared as public canon / spine, but has not yet absorbed field evidence.

**Assumptions / предположения:**

Long-form book structure is the right public container.

**Risks / риски:**

Writing the book too early may freeze untested assumptions.

**What would validate it / что могло бы подтвердить:**

Field evidence clarifies chapters and the book helps stabilize public understanding.

**What would falsify it / что могло бы опровергнуть:**

Shorter artifacts or tools prove more effective than a book at this stage.

---

### HYP-IPAC-033 — Mature/preliminary/speculative separation is necessary for architecture discipline

**Category:** Architectural hypotheses  
**Status:** `validated`  
**Confidence level:** `high`  
**Dangerous assumption:** `no`

**Формулировка:**

The project must distinguish mature, preliminary and speculative concepts to avoid contaminating architecture with attractive but untested ideas.

**К какой потребности относится:**

Need for research discipline and architecture stability.

**К какому архитектурному инварианту относится:**

AINV-IPAC-022, AINV-IPAC-024, AINV-IPAC-032

**Evidence / основания:**

Phase 2 and Phase 3 explicitly introduced maturity/status separation.

**Assumptions / предположения:**

Maturity labels will be respected in later work.

**Risks / риски:**

Speculative concepts may still dominate because they are energizing.

**What would validate it / что могло бы подтвердить:**

Architecture artifact includes only stable invariants and marks execution/speculative items separately.

**What would falsify it / что могло бы опровергнуть:**

Later documents mix metaphors, execution candidates and stable architecture without labels.

---

## 9. Правило обновления

```text
Статус гипотезы не повышается без evidence.
Evidence должно пройти маршрут: raw capture → review → decision → trace.
Execution-гипотезы не становятся архитектурой без проверки.
Спекулятивные гипотезы не становятся canon без операционализации и evidence.
```

## 10. Status

```yaml
artifact_id: PHASE3-HYPOTHESIS-REGISTRY-EXTENDED-IPAC-001
artifact_type: hypothesis_registry_artifact
version: v0.2
status: accepted-candidate
phase: Phase 3
project: IPaC / Information Production as Code
previous_artifacts:
  - PHASE1-NEED-ARTIFACT-IPAC-001
  - PHASE2-CONCEPT-ARTIFACT-IPAC-001
related_artifacts:
  - PHASE4-ARCHITECTURE-INVARIANTS-IPAC-001
```