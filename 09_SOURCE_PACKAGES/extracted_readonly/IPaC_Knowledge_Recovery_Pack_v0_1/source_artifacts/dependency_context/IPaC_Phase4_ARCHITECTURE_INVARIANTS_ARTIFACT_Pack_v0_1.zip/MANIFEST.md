# MANIFEST.md

# IPaC Phase 4 — ARCHITECTURE INVARIANTS ARTIFACT Pack v0.1

| Путь | Назначение |
|---|---|
| `docs/PHASE4_ARCHITECTURE_INVARIANTS_ARTIFACT_IPAC.md` | основной артефакт архитектурных инвариантов |
| `registers/PHASE4_ARCHITECTURE_INVARIANTS_REGISTER.csv` | CSV-реестр инвариантов |
| `registers/PHASE4_ARCHITECTURE_INVARIANTS_CATEGORY_SUMMARY.csv` | сводка по категориям |
| `registers/PHASE4_ARCHITECTURE_INVARIANTS_CONFIDENCE_SUMMARY.csv` | сводка по confidence |
| `maps/PHASE4_ARCHITECTURE_INVARIANTS_MAP.mmd` | Mermaid-карта архитектурных инвариантов |
| `templates/PHASE4_INVARIANT_REVIEW_TEMPLATE.md` | шаблон пересмотра инварианта |
| `status/PHASE4_ARCHITECTURE_INVARIANTS_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Важно

```text
Это не execution plan.
Это не MVP.
Это не каналы публикации.
Это архитектурное ядро.
```
