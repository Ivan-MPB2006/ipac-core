IPaC Phase 4 — ARCHITECTURE INVARIANTS ARTIFACT Pack v0.1

Назначение:
Пакет содержит исправленный Phase 4: ARCHITECTURE INVARIANTS / Архитектурные инварианты.

Это НЕ execution-фаза.
Это НЕ MVP.
Это НЕ план публикаций.
Это НЕ dashboard/runbook.

Документ извлекает:
1. Core system boundaries
2. Core entities
3. Stable relationships
4. Information flows
5. Governance principles
6. Knowledge lifecycle invariants
7. Human-AI role separation
8. What must not be broken
9. What is explicitly NOT architecture
10. Confidence level for each invariant

Главная формула:
Архитектура IPaC — это устойчивый контур живого знания, а не набор каналов, запусков или документов.
