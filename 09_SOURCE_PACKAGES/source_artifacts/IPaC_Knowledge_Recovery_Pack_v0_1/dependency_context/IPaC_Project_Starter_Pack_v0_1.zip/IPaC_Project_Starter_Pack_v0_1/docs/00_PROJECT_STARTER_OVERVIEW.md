# 00 — Project Starter Overview

## Статус

`IPaC Project Starter Pack v0.1` — первый собранный Core Recovery Package для запуска нового Project.

Он создаёт устойчивую точку старта после восстановления интеллектуальных активов из старой работы.

## Почему пакет нужен

Старая линия показала, что модель и чат могут поддерживать сильное мышление, но длинный чат быстро превращается в hidden context debt — скрытый контекстный долг.

Поэтому новый Project должен стартовать не из истории диалогов, а из отчуждаемых артефактов.

## Рабочая линия

```text
Old Chat / Archive
  ↓
Recovery Prompts
  ↓
Phase Artifacts
  ↓
Normalization
  ↓
Starter Pack
  ↓
New Project
```

## Состав ядра

- Root Need — зачем существует IPaC.
- Architecture Invariants — что нельзя ломать.
- Normalized Hypothesis Registry — что является гипотезой, а не фактом.
- Lessons Learned — как не повторить прежний context drift.

## Статистика пакета

| Показатель | Значение |
|---|---:|
| Архитектурных инвариантов | 35 |
| Нормализованных гипотез | 33 |
| Field-validated гипотез | 0 |
| Правил Project | 19 |
| Анти-паттернов | 9 |
| Уроков процесса | 32 |

## Главное ограничение

Новый Project должен оставаться в режиме controlled evolution — управляемой эволюции.

Он не должен сразу уходить в:

- Codex;
- MVP;
- каналы публикации;
- marketing;
- dashboard;
- execution plan.

Эти элементы уже есть как сигналы, но пока припаркованы.
