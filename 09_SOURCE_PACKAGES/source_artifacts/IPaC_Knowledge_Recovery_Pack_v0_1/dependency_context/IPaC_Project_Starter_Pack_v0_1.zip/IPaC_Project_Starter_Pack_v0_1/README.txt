IPaC Project Starter Pack v0.1
=================================

Это первый настоящий стартовый пакет для нового Project IPaC.

Что делать:
1. Загрузить ZIP в новый ChatGPT Project или распаковать в Obsidian/Git.
2. Открыть START_HERE.md.
3. Скопировать prompts/NEW_PROJECT_BOOT_PROMPT.md как первое сообщение в Project.
4. Не переходить к MVP/Execution до отдельного решения.
5. Следующая рекомендуемая фаза: PHASE 2 — CONCEPT ARTIFACT или Phase 2 prompt по ситуации.

Содержимое:
- docs/ — стартовое ядро, статус, правила, дорожная карта.
- prompts/ — промпт загрузки нового Project и следующий prompt для Phase 2.
- registers/ — machine-readable реестры.
- maps/ — Mermaid-карты.
- templates/ — шаблоны проверки.
- source_artifacts/ — исходные ZIP-пакеты и исходные документы.
- status/ — machine-readable статус пакета.
