# START HERE — IPaC Project Starter Pack v0.1

## 1. Что это

Это первый настоящий стартовый пакет IPaC для нового ChatGPT Project.

Он собран не из “длинного чата”, а из переносимых интеллектуальных активов:

```text
PHASE 1 — NEED ARTIFACT
PHASE 4 — ARCHITECTURE INVARIANTS
PHASE 3R — HYPOTHESIS REGISTRY NORMALIZATION
PHASE 8 — LESSONS LEARNED
```

Статус пакета: `accepted-candidate core`.

Это означает: пакет пригоден как стартовая основа, но не является финальным каноном.

---

## 2. Главная несущая формула

```text
Сложный смысл должен становиться исполнимым знанием.
```

Расширенная формула:

```text
IPaC нужен, чтобы живой сложный смысл стал управляемым, переносимым, проверяемым и исполнимым знанием.
```

Ключевое противоречие:

```text
Output стал дешёвым, смысл остался дорогим.
```

English:

```text
AI made output cheap. Now meaning is the bottleneck.
```

---

## 3. Что уже принято как рабочее ядро

| Слой | Артефакт | Статус | Роль |
|---|---|---|---|
| Need | PHASE 1 — NEED ARTIFACT | accepted-candidate | Корневой потребностный инвариант |
| Architecture | PHASE 4 — ARCHITECTURE INVARIANTS | accepted-candidate | Устойчивое архитектурное ядро |
| Hypotheses | PHASE 3R — HYPOTHESIS NORMALIZATION | accepted-candidate | Нормализованный реестр гипотез |
| Discipline | PHASE 8 — LESSONS LEARNED | accepted-candidate | Правила, анти-паттерны, уроки процесса |

---

## 4. Главный архитектурный контур

```text
Human Subject
  ↓
Knowledge Clump / Знаниевый Сгусток
  ↓
Knowledge Artifacts
  ↓
Canon
  ↓
Projection / Use
  ↓
Feedback / Evidence
  ↓
Review
  ↓
Decision
  ↓
Controlled Rebuild
  ↓
Trace
  ↓
Canon Update
```

Ключевой инвариант:

```text
Архитектура IPaC — это устойчивый контур живого знания,
а не набор каналов, запусков или документов.
```

---

## 5. Главные правила защиты от старых ошибок

1. Chat is workspace, not source-of-truth.  
   Чат — рабочее пространство рассуждений, а не источник истины.

2. Validated ≠ field validated.  
   Внутренняя связность не равна полевой проверке.

3. Execution candidates must not be placed in architecture core.  
   Кандидаты исполнения нельзя помещать в архитектурное ядро.

4. If Need, Architecture and Execution appear in one session, stop and split.  
   Если в одной сессии смешались Потребность, Архитектура и Исполнение — остановить и разделить.

5. Accepted knowledge must be externalized.  
   Принятое знание должно быть вынесено в артефакт, реестр или status.

---

## 6. Что припарковано

Не выброшено, но НЕ является стартовым каноном:

- Phase 4 Execution Artifact;
- Phase 3 v0.1 как wide recovery capture;
- Phase 3 v0.2 как источник, уже нормализованный через Phase 3R;
- LinkedIn / Telegram / Pinterest / YouTube;
- site anchor;
- dashboard;
- 89 Feedback Package;
- 90 / 71 Review;
- 72 Decision;
- 73 Trace как конкретные механизмы, если не отделены от инвариантов.

Эти элементы вернутся только на стадии MVP/MVI / Execution.

---

## 7. Следующий рекомендуемый ход

```text
Core Recovery Package
  ↓
PHASE 2 — CONCEPT ARTIFACT
  ↓
PHASE 5 — RESEARCH FINDINGS
  ↓
PHASE 6 — OPEN QUESTIONS
  ↓
Project Starter Pack v0.2
```

---

## 8. Как стартовать новый ChatGPT Project

Скопировать содержимое:

```text
prompts/NEW_PROJECT_BOOT_PROMPT.md
```

в первое сообщение нового Project.

Затем загрузить или подключить этот ZIP как источник.
