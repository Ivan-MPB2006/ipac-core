# IPaC Project Starter Pack v0.1

**Проект:** IPaC / Information Production as Code  
**Тип:** Project Starter Pack / Core Recovery Package  
**Версия:** v0.1  
**Дата сборки:** 2026-06-08  
**Статус:** starter-pack / accepted-candidate core  

## Назначение

Этот пакет собирает первое управляемое ядро IPaC для переноса в новый ChatGPT Project, Obsidian и Git.

Пакет НЕ является финальным каноном IPaC. Он является стартовой операционной базой, построенной из принятых Recovery Wave 1 артефактов.

## Accepted-candidate ядро

1. PHASE 1 — NEED ARTIFACT
2. PHASE 4 — ARCHITECTURE INVARIANTS
3. PHASE 3R — HYPOTHESIS REGISTRY NORMALIZATION
4. PHASE 8 — LESSONS LEARNED

## Ключевой статус

- `validated` означает internal/artifact-supported validation, если явно не указано field-tested или externally-validated.
- На момент сборки нет field-validated гипотез.
- Execution-кандидаты не входят в архитектурное ядро.
- Chat является reasoning workspace, а не source-of-truth.

## Быстрый старт

Откройте `START_HERE.md`, затем `prompts/NEW_PROJECT_BOOT_PROMPT.md`.
