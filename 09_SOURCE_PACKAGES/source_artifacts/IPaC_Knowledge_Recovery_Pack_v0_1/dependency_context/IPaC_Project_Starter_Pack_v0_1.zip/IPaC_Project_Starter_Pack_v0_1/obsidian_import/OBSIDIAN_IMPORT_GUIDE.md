# 07 — Obsidian Import Guide

## Рекомендуемая структура Vault

```text
/IPaC
  /00_Need
  /01_Recovery
  /02_Hypotheses
  /03_Concepts
  /04_Architecture
  /05_ADR
  /06_Experiments
  /07_MVP
  /08_Open_Questions
  /09_Project_Rules
  /10_Recovery_Notes
  /11_Source_Artifacts
  /Templates
```

## Куда положить этот пакет

```text
/IPaC/01_Recovery/IPaC_Project_Starter_Pack_v0_1/
```

## Разнести по слоям

- `docs/01_ROOT_NEED.md` → `/00_Need/`
- `docs/02_ARCHITECTURE_INVARIANTS_SUMMARY.md` → `/04_Architecture/`
- `docs/03_HYPOTHESIS_REGISTRY_SUMMARY.md` → `/02_Hypotheses/`
- `docs/04_SYSTEM_DISCIPLINE_AND_PROJECT_RULES.md` → `/09_Project_Rules/`
- `docs/05_PARKED_ITEMS_AND_NEXT_PHASES.md` → `/10_Recovery_Notes/`
- `source_artifacts/accepted_candidates/` → `/11_Source_Artifacts/Accepted/`
- `source_artifacts/parked_sources/` → `/11_Source_Artifacts/Parked/`

## Правило Obsidian

Obsidian не должен стать свалкой. Каждый файл должен иметь один из статусов:

```text
draft
accepted-candidate
accepted-canon
parked-source
superseded
rejected
```
