# MANIFEST.md

# IPaC Phase 1 — NEED ARTIFACT Pack v0.1

| Путь | Назначение |
|---|---|
| `docs/PHASE1_NEED_ARTIFACT_IPAC.md` | основной артефакт потребности |
| `registers/PHASE1_NEED_ARTIFACT_register.csv` | краткий реестр ключевых извлечений |
| `status/PHASE1_NEED_ARTIFACT_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Главная формула

```text
IPaC нужен, чтобы живой смысл стал управляемым, переносимым и исполнимым знанием.
```
