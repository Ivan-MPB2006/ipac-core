# MANIFEST.md

# IPaC Phase 6 — OPEN QUESTIONS ARTIFACT Pack v0.1

| Путь | Назначение |
|---|---|
| `docs/PHASE6_OPEN_QUESTIONS_ARTIFACT_IPAC.md` | основной артефакт открытых вопросов |
| `registers/PHASE6_OPEN_QUESTIONS_REGISTER.csv` | реестр открытых вопросов |
| `registers/PHASE6_CONTRADICTIONS_REGISTER.csv` | реестр противоречий |
| `registers/PHASE6_ASSUMPTIONS_REGISTER.csv` | реестр предположений |
| `registers/PHASE6_VALIDATION_GAPS_REGISTER.csv` | реестр пробелов валидации |
| `registers/PHASE6_TERMINOLOGY_RISKS_REGISTER.csv` | реестр терминологических рисков |
| `registers/PHASE6_PARKED_QUESTIONS_REGISTER.csv` | реестр припаркованных вопросов |
| `registers/PHASE6_NEXT_ACTIONS_REGISTER.csv` | реестр типов следующих действий |
| `maps/PHASE6_OPEN_QUESTIONS_MAP.mmd` | Mermaid-карта открытых вопросов |
| `maps/PHASE6_UNCERTAINTY_TO_ACTION_MAP.mmd` | Mermaid-карта неопределённость → действие |
| `templates/PHASE6_OPEN_QUESTION_REVIEW_TEMPLATE.md` | шаблон ревью открытого вопроса |
| `status/PHASE6_OPEN_QUESTIONS_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Critical rule

```text
Do not close uncertainty prematurely.
Open questions protect IPaC from false maturity.
```
