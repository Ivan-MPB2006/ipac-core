IPaC Phase 2 — CONCEPT ARTIFACT Pack v0.2

Назначение:
Переносимый инженерный артефакт концепта IPaC для нового ChatGPT Project / Obsidian / Git.

Пакет НЕ развивает IPaC, НЕ проектирует архитектуру, НЕ делает MVP и НЕ переходит к execution.
Он извлекает концептуальное ядро из старого контекста и фиксирует границы.

Использование:
1. Открыть docs/PHASE2_CONCEPT_ARTIFACT_IPAC.md.
2. Импортировать stable core concepts в новый Project.
3. Использовать glossary/PHASE2_GLOSSARY.md как рабочий словарь.
4. Использовать registers/PHASE2_CONCEPT_REGISTER.csv для traceability.
5. Держать parked/speculative elements вне концептуального ядра.

Главное:
IPaC нужен, чтобы живой сложный смысл стал управляемым, переносимым, проверяемым и исполнимым знанием.
