# MANIFEST.md

# IPaC Phase 2 — CONCEPT ARTIFACT Pack v0.2

| Путь | Назначение |
|---|---|
| `docs/PHASE2_CONCEPT_ARTIFACT_IPAC.md` | основной артефакт концепта |
| `registers/PHASE2_CONCEPT_REGISTER.csv` | CSV-ready реестр концептов |
| `registers/PHASE2_CONCEPT_MATURITY_REGISTER.csv` | сводка зрелости концептов |
| `registers/PHASE2_CONCEPT_RISKS_REGISTER.csv` | реестр рисков концепта |
| `maps/PHASE2_CONCEPTUAL_MODEL.mmd` | Mermaid-концептуальная модель |
| `glossary/PHASE2_GLOSSARY.md` | рабочий глоссарий |
| `templates/PHASE2_CONCEPT_REVIEW_TEMPLATE.md` | шаблон ревью концепта |
| `status/PHASE2_CONCEPT_ARTIFACT_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Critical distinctions

```text
Concept ≠ Architecture
Architecture ≠ Execution
Beautiful formula ≠ field validation
Tool ≠ IPaC
```
