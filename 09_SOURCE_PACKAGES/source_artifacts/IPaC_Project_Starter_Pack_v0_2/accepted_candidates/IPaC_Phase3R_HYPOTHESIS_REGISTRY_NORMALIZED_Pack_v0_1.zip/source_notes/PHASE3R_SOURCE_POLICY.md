# Phase 3R Source Policy

1. Use Phase 3 v0.2 as the working registry.
2. Use Phase 3 v0.1 only as parked-source / delta-source.
3. Do not merge v0.1 and v0.2 by hypothesis ID. IDs are not semantically stable across the two packages.
4. Do not treat Phase 2 as accepted in the new Project line until Phase 2 is separately recovered and reviewed.
5. Keep execution hypotheses parked until MVP/MVI design.
