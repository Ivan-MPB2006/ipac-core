PHASE 3R — HYPOTHESIS REGISTRY NORMALIZATION

This package normalizes Phase 3 hypothesis recovery for IPaC.

v0.2 is accepted as the working registry.
v0.1 is preserved as a parked source and delta source.

Main outputs:
- docs/PHASE3R_HYPOTHESIS_REGISTRY_NORMALIZATION.md
- registers/PHASE3R_HYPOTHESIS_REGISTER_NORMALIZED.csv
- registers/PHASE3R_DELTA_FROM_V01.csv
- registers/PHASE3R_DELTA_ADDITIONS_FROM_V01.csv
- registers/PHASE3R_EXECUTION_HYPOTHESES_PARKED.csv
- registers/PHASE3R_DANGEROUS_AND_RISK_FLAGGED.csv
- status/PHASE3R_status.json

Critical note: validated means internal/artifact-supported validation, not field validation.
