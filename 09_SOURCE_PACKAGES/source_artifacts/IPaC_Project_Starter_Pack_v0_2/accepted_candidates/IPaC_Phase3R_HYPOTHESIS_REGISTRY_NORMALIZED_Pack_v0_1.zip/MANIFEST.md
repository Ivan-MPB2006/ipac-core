# MANIFEST — PHASE 3R HYPOTHESIS REGISTRY NORMALIZATION

## Package

IPaC_Phase3R_HYPOTHESIS_REGISTRY_NORMALIZED_Pack_v0_1

## Status

accepted-candidate

## Contents

- README.txt
- MANIFEST.md
- docs/PHASE3R_HYPOTHESIS_REGISTRY_NORMALIZATION.md
- registers/PHASE3R_HYPOTHESIS_REGISTER_NORMALIZED.csv
- registers/PHASE3R_NORMALIZATION_ACTION_SUMMARY.csv
- registers/PHASE3R_VALIDATION_SCOPE_SUMMARY.csv
- registers/PHASE3R_DELTA_FROM_V01.csv
- registers/PHASE3R_DELTA_ADDITIONS_FROM_V01.csv
- registers/PHASE3R_EXECUTION_HYPOTHESES_PARKED.csv
- registers/PHASE3R_DANGEROUS_AND_RISK_FLAGGED.csv
- maps/PHASE3R_NORMALIZATION_FLOW.mmd
- templates/PHASE3R_HYPOTHESIS_REVIEW_TEMPLATE.md
- status/PHASE3R_status.json

## Source inputs

- IPaC_Phase3_HYPOTHESIS_REGISTRY_EXTENDED_Pack_v0_2
- IPaC_Phase3_HYPOTHESIS_REGISTRY_Pack_v0_1

## Core normalization rule

`validated` in the old registry means internal/artifact-supported validation only. It does not mean field validation.
