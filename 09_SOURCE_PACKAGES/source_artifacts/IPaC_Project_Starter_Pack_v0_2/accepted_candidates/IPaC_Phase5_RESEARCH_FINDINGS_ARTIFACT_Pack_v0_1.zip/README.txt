IPaC Phase 5 — RESEARCH FINDINGS ARTIFACT Pack v0.1

Назначение:
Пакет восстанавливает Research Map из предыдущей работы по IPaC.

Ограничения:
- no new web research;
- no new sources;
- no field validation claimed;
- analogies are not evidence;
- tools are not proof of architecture.

Следующий этап: PHASE 6 — OPEN QUESTIONS.
