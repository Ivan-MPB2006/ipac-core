# MANIFEST.md

# IPaC Phase 5 — RESEARCH FINDINGS ARTIFACT Pack v0.1

| Путь | Назначение |
|---|---|
| `docs/PHASE5_RESEARCH_FINDINGS_ARTIFACT_IPAC.md` | основной артефакт результатов исследований |
| `registers/PHASE5_RESEARCH_FINDINGS_REGISTER.csv` | реестр research findings |
| `registers/PHASE5_SOURCE_ANALOGY_REGISTER.csv` | реестр источников и аналогий |
| `registers/PHASE5_RESEARCH_GAPS_REGISTER.csv` | реестр исследовательских пробелов |
| `registers/PHASE5_RESEARCH_RISKS_REGISTER.csv` | реестр рисков исследований |
| `registers/PHASE5_HYPOTHESIS_SUPPORT_REGISTER.csv` | связь findings с гипотезами |
| `registers/PHASE5_SOURCE_LIMITATIONS_REGISTER.csv` | ограничения источников |
| `registers/PHASE5_IMPORT_RULES_REGISTER.csv` | правила импорта исследований |
| `maps/PHASE5_RESEARCH_MAP.mmd` | Mermaid-карта исследований |
| `maps/PHASE5_EVIDENCE_LADDER_MAP.mmd` | Mermaid-лестница свидетельств |
| `templates/PHASE5_RESEARCH_REVIEW_TEMPLATE.md` | шаблон ревью research finding |
| `status/PHASE5_RESEARCH_FINDINGS_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Critical rule

```text
Research support ≠ hypothesis validation ≠ field validation ≠ external validation.
```
