IPaC Phase 4 — EXECUTION ARTIFACT Pack v0.1

Назначение:
Пакет содержит отчуждаемый документ EXECUTION ARTIFACT / Артефакт Исполнения
для проекта IPaC / Information Production as Code.

Документ фиксирует:
- переход к MVI Execution;
- минимальный активный контур;
- порядок boot нового Project;
- Day 0 / Day 1 execution route;
- feedback discipline;
- критерии успешного выполнения Phase 4;
- recovery mode;
- связь с 87–90.

Как использовать:
1. Открыть docs/PHASE4_EXECUTION_ARTIFACT_IPAC.md.
2. Использовать как execution layer для нового Project / нового тарифного плана.
3. Работать через runbook/PHASE4_EXECUTION_RUNBOOK.md.
4. Проверять чеклист checklists/PHASE4_EXECUTION_CHECKLIST.md.
5. Использовать registers/PHASE4_EXECUTION_REGISTER.csv для контроля статусов.
6. Следующий слой после выполнения — Phase 5 Field Evidence / Validation Artifact.

Главная формула:
Не расширять поле. Пройти поле.
