# PHASE4_EXECUTION_RUNBOOK.md

# Phase 4 Execution Runbook

## Run order

```text
0. Boot нового Project
1. Открыть 88 Dashboard
2. Установить current_status
3. Выбрать one_next_action
4. Зафиксировать not_doing
5. Выбрать первый внешний ход
6. Запустить trusted reviewers / LinkedIn soft signal
7. Подготовить site anchor
8. Собирать raw feedback
9. Заполнить 89 Feedback Package
10. Провести 90 / 71 Review
11. Передать решения в 72
12. Подготовить trace для 73
```

## Daily control

```yaml
current_status:
one_next_action:
not_doing:
```

## Rule

```text
3 ± 2 active items.
```
