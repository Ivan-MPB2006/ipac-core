# MANIFEST.md

# IPaC Phase 4 — EXECUTION ARTIFACT Pack v0.1

| Путь | Назначение |
|---|---|
| `docs/PHASE4_EXECUTION_ARTIFACT_IPAC.md` | основной артефакт исполнения |
| `runbook/PHASE4_EXECUTION_RUNBOOK.md` | краткий execution runbook |
| `checklists/PHASE4_EXECUTION_CHECKLIST.md` | checklist выполнения |
| `registers/PHASE4_EXECUTION_REGISTER.csv` | реестр execution-статусов |
| `maps/PHASE4_EXECUTION_FLOW.mmd` | Mermaid-карта исполнения |
| `status/PHASE4_EXECUTION_ARTIFACT_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Главная формула

```text
Не расширять поле.
Пройти поле.
```
