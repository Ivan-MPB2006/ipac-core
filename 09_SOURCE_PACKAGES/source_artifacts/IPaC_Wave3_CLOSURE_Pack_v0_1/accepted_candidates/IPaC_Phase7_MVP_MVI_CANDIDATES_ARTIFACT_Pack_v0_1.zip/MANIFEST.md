# MANIFEST.md

# IPaC Phase 7 — MVP / MVI CANDIDATES ARTIFACT Pack v0.1

| Путь | Назначение |
|---|---|
| `docs/PHASE7_MVP_MVI_CANDIDATES_ARTIFACT_IPAC.md` | основной артефакт кандидатов MVP / MVI |
| `registers/PHASE7_MVP_MVI_CANDIDATES_REGISTER.csv` | реестр кандидатов |
| `registers/PHASE7_VALIDATION_TARGETS_REGISTER.csv` | реестр целей проверки |
| `registers/PHASE7_FIELD_EVIDENCE_REGISTER.csv` | реестр полевых свидетельств |
| `registers/PHASE7_CANDIDATE_RISK_REGISTER.csv` | реестр рисков кандидатов |
| `registers/PHASE7_CANDIDATE_PRIORITY_REGISTER.csv` | предварительная приоритизация |
| `registers/PHASE7_PARKED_REJECTED_CANDIDATES_REGISTER.csv` | припаркованные / отклонённые кандидаты |
| `maps/PHASE7_MVP_MVI_CANDIDATE_MAP.mmd` | Mermaid-карта кандидатов |
| `maps/PHASE7_VALIDATION_FLOW_MAP.mmd` | Mermaid-карта validation flow |
| `templates/PHASE7_CANDIDATE_REVIEW_TEMPLATE.md` | шаблон ревью кандидата |
| `status/PHASE7_MVP_MVI_CANDIDATES_status.json` | machine-readable status |
| `README.txt` | инструкция по использованию |

## Critical rule

```text
Phase 7 maps MVP / MVI candidates.
It does not select, launch, roadmap, or validate them.
```
