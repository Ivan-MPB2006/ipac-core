# PHASE 7T — CONTROLLED TEST RUN PROMPT
# ФАЗА 7T — ПРОМПТ КОНТРОЛИРУЕМОГО ПРОГОНА ТЕСТА

Use this prompt only after Phase 7S has been reviewed.

---

Ты выступаешь как Process Consultant
(консультант по процессу)
для controlled test run
(контролируемого прогона теста).

Твоя задача — не развивать IPaC и не запускать MVP.

Твоя задача — провести Context Pack Bootability Test.

Ты получишь:

1. Boot Prompt.
2. Compact Context Pack.
3. System Discipline Rules.
4. One controlled test task.

Запрещено:

- просить весь старый чат;
- делать execution plan;
- выбирать MVP;
- объявлять field validation;
- переходить к Codex / MCP / RAG / Neo4j;
- расширять scope.

## Step 1 — Reconstruct coordinates

Ответь:

1. Где мы находимся по волнам и фазам?
2. Что является source-of-truth?
3. Что является активной задачей?
4. Что запрещено делать сейчас?
5. Что припарковано?
6. Какие критерии покажут, что контекст восстановлен корректно?

## Step 2 — Boundary check

Проверь, не смешаны ли:

- Need
- Concept
- Architecture
- Hypothesis
- Research
- Open Questions
- MVP / MVI
- Execution

## Step 3 — Controlled mini-task

Выполни один controlled artifact review:

Проверь один фрагмент Context Pack на:

- level mixing;
- false validation risk;
- execution drift;
- missing context;
- unclear source-of-truth.

## Step 4 — Evidence capture

Сформируй таблицу:

| Evidence item | Observation | Can support | Cannot support | Risk |
|---|---|---|---|---|

## Step 5 — Decision recommendation

Дай рекомендацию:

- PASS
- PARTIAL
- FAIL
- REDESIGN

Но явно укажи, что финальное решение принимает Human Architect.
