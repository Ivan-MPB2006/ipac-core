# Context Pack Generation Prompt
# Промпт генерации контекстного пакета

Use this to create a compact Context Pack for Phase 7T.

---

Сформируй компактный Context Pack для запуска нового Project / clean chat.

Цель:
передать минимально достаточный контекст для Context Pack Bootability Test.

Не включай весь старый чат.
Не включай полный архив фаз.
Не включай execution artifacts.
Не включай Codex / MCP / RAG / Neo4j задачи.

Context Pack должен включать:

1. Current coordinates
2. Root Need
3. Concept Core
4. Architecture Invariants
5. Hypothesis Summary
6. Research Map Summary
7. Open Questions Top List
8. Validation Boundaries
9. Lessons Learned / System Discipline
10. Parking Lot
11. Active Phase 7S / 7T boundary
12. Test task

Ограничение:
Context Pack должен быть коротким, bootable и не превращаться в новый длинный чат.

На выходе дай Markdown-документ:

# IPaC Context Pack for Phase 7T
