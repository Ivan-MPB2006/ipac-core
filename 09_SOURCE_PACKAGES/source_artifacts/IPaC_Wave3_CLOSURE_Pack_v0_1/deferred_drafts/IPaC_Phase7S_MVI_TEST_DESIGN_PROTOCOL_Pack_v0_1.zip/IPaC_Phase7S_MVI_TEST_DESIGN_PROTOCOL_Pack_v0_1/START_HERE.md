# IPaC Phase 7S — MVI Test Design Protocol v0.1

## Назначение

Этот пакет фиксирует дизайн первого минимального проверочного цикла для IPaC:

**MVI-IPAC-003 — Context Pack Bootability Test**  
(Тест запуска нового Project по контекстному пакету)

Это **не запуск MVP**, **не execution plan**, **не продуктовый roadmap** и **не внешняя валидация**.

Phase 7S отвечает на вопрос:

```text
Как спроектировать минимальный тест, который покажет,
может ли Context Pack восстановить рабочее состояние проекта
без длинного старого чата и снизить context drift?
```

## Текущая координата

```text
Recovery Program
├─ Wave 1 — Core Recovery ✅
├─ Wave 2 — Knowledge Recovery ✅
└─ Wave 3 — Validation / MVP Candidate Recovery
   ├─ Phase 7  — MVP/MVI Candidates ✅
   ├─ Phase 7R — Candidate Review & Selection ✅
   └─ Phase 7S — MVI Test Design Protocol ✅ current
```

## Первый выбранный тест

```text
MVI-IPAC-003 — Context Pack Bootability Test
```

## Компаньон ядра

```text
MVI-IPAC-005 — Need → Artifact → Review cycle
```

Компаньон не запускается как отдельный большой MVP. Он встраивается в тест как минимальная проверка: может ли новый Project произвести один контролируемый артефакт и провести review.

## Следующий шаг после этого пакета

```text
Phase 7T — Controlled Test Run
(контролируемый прогон теста)
```

Но только после ручного review этого Phase 7S пакета.
