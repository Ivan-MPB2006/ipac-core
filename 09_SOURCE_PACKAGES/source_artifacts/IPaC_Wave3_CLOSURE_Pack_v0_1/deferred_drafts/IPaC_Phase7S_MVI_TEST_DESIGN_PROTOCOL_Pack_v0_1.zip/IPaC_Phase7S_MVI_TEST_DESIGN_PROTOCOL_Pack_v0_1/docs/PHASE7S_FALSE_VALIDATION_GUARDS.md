# PHASE 7S — False Validation Guards
# Защита от ложной валидации

## Core rule

```text
A successful boot test validates only bootability of the Context Pack.
It does not validate IPaC as a product, market need, or methodology.
```

Перевод:

```text
Успешный boot-тест подтверждает только запускаемость Context Pack.
Он не подтверждает IPaC как продукт, рыночную потребность или методологию целиком.
```

## Guard 1 — No field validation claim

Запрещено после теста писать:

```text
IPaC validated.
```

Разрешено писать:

```text
Context Pack bootability received internal evidence.
```

## Guard 2 — No external need claim

Тест не проверяет внешнюю потребность. Любой вывод о внешней потребности должен быть запрещён до External Reviewer / Field Evidence loop.

## Guard 3 — No toolchain conclusion

Тест не проверяет Obsidian / Git / Codex / MCP / RAG / Neo4j как полноценную инфраструктуру.

## Guard 4 — No MVP selection by enthusiasm

Если тест прошёл успешно, это не означает, что кандидат надо немедленно запускать как MVP.

## Guard 5 — No polished output bias

Красиво оформленный ответ не является evidence. Evidence — это соответствие критериям, устойчивость границ и обнаружение missing context.

## Guard 6 — No silence-as-success

Если модель не называет противоречий и рисков, это не успех. Это может быть false coherence.

## Guard 7 — Preserve no-signal evidence

Если тест не даёт сигналов, это тоже результат. Нужно фиксировать no-signal, а не дорисовывать выводы.

## Guard 8 — Human architect decision

AI может предложить оценку, но решение pass / partial / fail принимает Human Architect после review.
