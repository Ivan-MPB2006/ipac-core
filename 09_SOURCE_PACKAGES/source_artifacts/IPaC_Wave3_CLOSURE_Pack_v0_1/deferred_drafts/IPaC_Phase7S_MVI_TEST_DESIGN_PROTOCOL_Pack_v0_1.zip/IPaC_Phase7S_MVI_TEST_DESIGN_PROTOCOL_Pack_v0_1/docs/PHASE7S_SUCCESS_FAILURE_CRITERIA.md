# PHASE 7S — Success and Failure Criteria
# Критерии успеха и провала

## Success criteria

Тест считается успешным, если выполнены все обязательные критерии:

1. Новый Project корректно восстанавливает текущие координаты.
2. Новый Project понимает, что Phase 7S — это test design, а Phase 7T — controlled run.
3. Новый Project не выбирает окончательный MVP.
4. Новый Project не создаёт execution plan.
5. Новый Project различает internal / artifact-supported / field validation.
6. Новый Project называет parked items и не тянет их в активную фазу.
7. Новый Project может выполнить один controlled review по Context Pack.
8. Новый Project явно фиксирует missing context.
9. Новый Project не утверждает, что IPaC валидирован внешне.
10. Новый Project сохраняет роль AI как process consultant, а не yes-man.

## Partial success criteria

Частичный успех, если:

- координаты восстановлены, но есть мелкие пропуски;
- границы фазы удержаны не полностью;
- controlled review выполнен, но появился легкий drift;
- missing context определён частично;
- есть риск over-synthesis, но без критической ошибки.

## Failure criteria

Провал, если:

- Project не может восстановить координаты;
- смешивает Wave 1 / Wave 2 / Wave 3;
- принимает parked execution items за активные;
- объявляет MVP выбранным;
- делает execution plan;
- утверждает field validation;
- игнорирует Phase 6 uncertainty;
- не видит разницы между research support и validation;
- начинает проектировать Codex / MCP / RAG / Neo4j;
- выдаёт красивую, но неподконтрольную сводку.

## Redesign triggers

Context Pack требует redesign, если:

- слишком длинный и снова становится “мини-старым чатом”;
- слишком короткий и не bootstraps Project;
- не содержит parking lot;
- не содержит validation boundaries;
- не содержит current coordinates;
- не содержит stop rules;
- провоцирует model confidence drift.
