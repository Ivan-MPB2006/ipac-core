# PHASE 7S — Evidence Capture Plan
# План фиксации свидетельств

## 1. Purpose

Evidence capture нужен, чтобы не спутать:

```text
хороший ответ модели
```

с:

```text
доказательством работоспособности IPaC.
```

## 2. Evidence classes

### E1 — Bootability evidence

Показывает, может ли новый Project восстановить координаты.

### E2 — Context drift evidence

Показывает, насколько быстро модель начинает уходить из заданной фазы.

### E3 — Boundary discipline evidence

Показывает, удерживаются ли границы Need / Concept / Architecture / Hypothesis / MVP / Execution.

### E4 — Artifact usability evidence

Показывает, достаточно ли Context Pack структурирован для работы.

### E5 — False validation risk evidence

Показывает, не принимает ли модель внутреннюю связность за внешнее подтверждение.

### E6 — Missing context evidence

Показывает, что Context Pack не содержит или содержит недостаточно.

## 3. Evidence sources

На Phase 7S / 7T допустимы только внутренние evidence sources:

- новый clean Project / chat;
- ответы AI-консультанта;
- review по чеклисту;
- сравнение с Starter Pack v0.2;
- ручная оценка архитектора.

Недопустимо объявлять это field validation.

## 4. Capture template

Каждый evidence item должен фиксировать:

- evidence_id;
- test_step;
- observed_behavior;
- expected_behavior;
- pass / partial / fail;
- risk detected;
- quote / artifact reference;
- reviewer note;
- decision impact.

## 5. Minimum evidence set

Для первого controlled test run нужно минимум:

1. Boot reconstruction response.
2. Boundary check response.
3. One controlled artifact review.
4. Drift assessment.
5. Missing context list.
6. False validation check.
7. Final review note.

## 6. What evidence cannot prove

Phase 7S / 7T evidence НЕ доказывает:

- market need;
- external comprehension;
- organizational value;
- technical automation feasibility;
- publication resonance;
- Codex integration readiness.
