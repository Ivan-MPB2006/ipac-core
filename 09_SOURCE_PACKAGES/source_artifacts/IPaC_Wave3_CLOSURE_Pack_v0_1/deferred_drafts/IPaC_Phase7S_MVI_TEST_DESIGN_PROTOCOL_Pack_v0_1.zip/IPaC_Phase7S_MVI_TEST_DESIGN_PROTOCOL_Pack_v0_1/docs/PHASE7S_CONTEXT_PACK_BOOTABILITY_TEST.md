# Context Pack Bootability Test
# Тест запуска Project по контекстному пакету

## 1. Test name

```text
MVI-IPAC-003-S — Context Pack Bootability Test
```

## 2. Test question

```text
Может ли новый Project корректно восстановить состояние IPaC,
если ему дать только компактный Context Pack и правила дисциплины,
а не весь старый чат?
```

## 3. Input package

Минимальный Context Pack должен включать:

1. Current coordinates.
2. Root Need.
3. Concept Core.
4. Architecture Invariants.
5. Normalized Hypothesis Summary.
6. Research Map Summary.
7. Open Questions Top List.
8. Lessons Learned / System Discipline.
9. Parking Lot.
10. Next Phase boundary.

## 4. Clean-room condition

Новый тестовый чат не должен получать:

- полный старый чат;
- все исходные ZIP-пакеты;
- execution artifacts;
- публичные каналы;
- Codex / MCP / RAG / Neo4j задачи.

## 5. Boot task

Новый Project должен ответить:

```text
1. Где мы находимся по волнам и фазам?
2. Что является source-of-truth?
3. Что является активной задачей?
4. Что запрещено делать сейчас?
5. Какие элементы припаркованы?
6. Какие критерии покажут, что контекст восстановлен корректно?
```

## 6. Controlled task

После boot task новый Project должен выполнить один малый тестовый артефакт:

```text
Mini Artifact Review:
Проверь один фрагмент Context Pack на смешение уровней Need / Concept / Architecture / Execution.
```

или:

```text
Mini Need → Artifact → Review:
Возьми одну потребностную формулу и проверь,
можно ли превратить её в управляемый артефакт без ухода в execution.
```

## 7. Evidence to capture

- Did the model reconstruct current coordinates correctly?
- Did it keep Phase 7S / Phase 7T boundary?
- Did it avoid execution plan?
- Did it identify parked items?
- Did it preserve distinction between validation levels?
- Did it ask for missing context responsibly?
- Did it hallucinate accepted artifacts?
- Did it overclaim field validation?

## 8. Success signal

Тест считается успешным, если новый Project может:

- восстановить координаты;
- удержать границы фазы;
- выполнить один controlled review;
- не уйти в execution;
- явно обозначить ограничения и неопределённость.

## 9. Failure signal

Тест провален, если новый Project:

- объявляет MVP выбранным к запуску;
- смешивает Context Pack с полным source-of-truth;
- утверждает field validation;
- забывает Phase 6 uncertainty;
- превращает Phase 7S в execution plan;
- делает Codex / MCP / RAG центральной задачей.
