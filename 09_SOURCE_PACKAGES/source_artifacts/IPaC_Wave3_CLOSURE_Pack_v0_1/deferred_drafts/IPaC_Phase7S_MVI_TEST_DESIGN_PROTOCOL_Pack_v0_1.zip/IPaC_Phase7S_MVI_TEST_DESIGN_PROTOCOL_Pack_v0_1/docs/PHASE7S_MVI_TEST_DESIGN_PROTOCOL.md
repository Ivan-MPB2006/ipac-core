# PHASE 7S — MVI Test Design Protocol
# ФАЗА 7S — Протокол дизайна MVI-теста

## 1. Purpose / Назначение

Phase 7S проектирует первый минимальный проверочный цикл IPaC, выбранный на Phase 7R:

```text
MVI-IPAC-003 — Context Pack Bootability Test
```

Цель теста — не доказать IPaC целиком, а проверить один критический механизм:

```text
Может ли компактный Context Pack восстановить рабочее состояние нового Project
без переноса длинного старого чата и снизить риск context drift?
```

## 2. Why this test first / Почему этот тест первый

Context Pack workflow выбран первым, потому что он:

- минимален;
- низко зависит от инструментов;
- не требует внешней аудитории;
- не требует Codex / MCP / RAG / Neo4j;
- проверяет главную процессную гипотезу: “память должна быть артефактной, а чат — рабочим пространством рассуждения”;
- даёт evidence signal для нового Project до перехода во внешнее поле.

## 3. Test hypothesis / Проверяемая гипотеза

```text
Если новый Project получает компактный, структурированный Context Pack,
то он может восстановить рабочее состояние IPaC лучше,
чем при продолжении длинного старого чата.
```

## 4. Related hypotheses / Связанные гипотезы

- Human + AI can hold complexity better than ordinary long chat.
- Context Pack reduces context drift.
- Artifact-based memory is more stable than chat memory.
- AI can act as process consultant, not only answer generator.
- Need → Artifact → Review can preserve living meaning while creating manageable artifacts.

## 5. What the test validates / Что тест может проверить

Тест может дать свидетельства о том, что:

- Context Pack достаточен для bootstrapping нового Project;
- новый чат может работать по правилам System Discipline;
- active context можно удерживать без полного старого диалога;
- артефакты лучше поддерживают traceability, чем длинный чат;
- процессный консультант может удерживать фазу и не уходить в execution.

## 6. What the test does NOT validate / Чего тест НЕ доказывает

Тест НЕ доказывает:

- наличие внешнего рынка;
- field validation IPaC;
- полную работоспособность методологии;
- ценность IPaC для организации;
- техническую реализуемость Codex / MCP / RAG / Neo4j;
- пригодность публичных каналов;
- готовность к MVP-продукту.

## 7. Test object / Объект теста

Тестируемый объект:

```text
Context Pack as bootable source-of-truth slice
```

Перевод:

```text
Контекстный пакет как запускаемый срез источника истины
```

## 8. Minimal test unit / Минимальная единица теста

Один новый Project / чат должен получить только:

1. Boot Prompt.
2. Compact Context Pack.
3. System Discipline Rules.
4. One test task: produce a controlled artifact or review.

Запрещено давать новому Project весь старый чат.

## 9. Test run outline / Контур прогона

```text
Prepare Context Pack
↓
Start clean Project / clean chat
↓
Boot with Context Pack only
↓
Ask model to reconstruct current coordinates
↓
Ask model to perform one controlled task
↓
Capture evidence
↓
Review drift / missing context / false assumptions
↓
Decide: pass / partial / fail / redesign
```

## 10. Companion check / Проверка-компаньон

Внутри теста можно использовать малый фрагмент MVI-IPAC-005:

```text
Need → Artifact → Review
```

Но только как один контролируемый микрошаг, например:

```text
Сформируй mini Need Review или Artifact Review по уже принятому фрагменту Starter Pack.
```

Нельзя превращать компаньон в отдельный большой MVP.

## 11. Review decision states / Состояния решения после теста

- PASS — пакет достаточен для bootstrapping и удержания фазы.
- PARTIAL — пакет запускает Project, но есть пробелы или drift.
- FAIL — пакет не удерживает контекст или модель делает ложные выводы.
- REDESIGN — нужен новый формат Context Pack.

## 12. Status

Phase 7S проектирует тест. Запуск теста относится к следующей фазе:

```text
Phase 7T — Controlled Test Run
```
