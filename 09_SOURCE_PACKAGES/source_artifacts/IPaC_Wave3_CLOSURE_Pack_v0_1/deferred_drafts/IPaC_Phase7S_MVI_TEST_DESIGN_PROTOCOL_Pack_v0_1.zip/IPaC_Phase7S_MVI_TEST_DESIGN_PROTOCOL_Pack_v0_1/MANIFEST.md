# MANIFEST — IPaC Phase 7S MVI Test Design Protocol Pack v0.1

Generated: 2026-06-08T20:00:19Z

## Artifact identity

- Program: IPaC Recovery Program
- Wave: Wave 3 — Validation / MVP Candidate Recovery
- Phase: Phase 7S
- Artifact type: MVI_TEST_DESIGN_PROTOCOL
- Status: accepted-candidate
- Source mode: derived from accepted recovery artifacts and Phase 7R selection

## Included files

```text
START_HERE.md
README.txt
MANIFEST.md

docs/
  PHASE7S_MVI_TEST_DESIGN_PROTOCOL.md
  PHASE7S_CONTEXT_PACK_BOOTABILITY_TEST.md
  PHASE7S_EVIDENCE_CAPTURE_PLAN.md
  PHASE7S_SUCCESS_FAILURE_CRITERIA.md
  PHASE7S_FALSE_VALIDATION_GUARDS.md
  PHASE7S_NEXT_COORDINATES.md

registers/
  PHASE7S_TEST_DESIGN_REGISTER.csv
  PHASE7S_SUCCESS_CRITERIA_REGISTER.csv
  PHASE7S_FAILURE_CRITERIA_REGISTER.csv
  PHASE7S_EVIDENCE_CAPTURE_REGISTER.csv
  PHASE7S_STOP_RULES_REGISTER.csv
  PHASE7S_RISK_REGISTER.csv
  PHASE7S_TEST_RUN_LOG_TEMPLATE.csv

maps/
  PHASE7S_TEST_FLOW.mmd
  PHASE7S_EVIDENCE_FLOW.mmd

templates/
  CONTEXT_PACK_BOOTABILITY_TEST_TEMPLATE.md
  EVIDENCE_CAPTURE_TEMPLATE.md
  TEST_REVIEW_TEMPLATE.md
  SESSION_BOOT_CHECKLIST.md

prompts/
  PHASE7T_CONTROLLED_TEST_RUN_PROMPT.md
  CONTEXT_PACK_GENERATION_PROMPT.md

status/
  PHASE7S_status.json

source_artifacts/
  REFERENCED_ACCEPTED_CONTEXT.md
```

## Non-goals

- Does not execute the test.
- Does not select final MVP.
- Does not claim field validation.
- Does not create product roadmap.
- Does not introduce Codex / MCP / RAG / Neo4j execution.
