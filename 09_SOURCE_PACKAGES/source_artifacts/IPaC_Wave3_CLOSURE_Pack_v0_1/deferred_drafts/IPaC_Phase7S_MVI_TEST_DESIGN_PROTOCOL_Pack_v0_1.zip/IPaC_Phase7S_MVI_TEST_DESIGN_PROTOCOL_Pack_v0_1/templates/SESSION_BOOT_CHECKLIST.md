# Session Boot Checklist

Before running Phase 7T, confirm:

- [ ] We are not launching MVP.
- [ ] We are not creating execution plan.
- [ ] We are not claiming field validation.
- [ ] We are testing Context Pack bootability only.
- [ ] Full old chat is not provided.
- [ ] Parked items remain parked.
- [ ] Success and failure criteria are visible.
- [ ] Evidence capture template is ready.
- [ ] Human Architect will make final pass / partial / fail / redesign decision.
