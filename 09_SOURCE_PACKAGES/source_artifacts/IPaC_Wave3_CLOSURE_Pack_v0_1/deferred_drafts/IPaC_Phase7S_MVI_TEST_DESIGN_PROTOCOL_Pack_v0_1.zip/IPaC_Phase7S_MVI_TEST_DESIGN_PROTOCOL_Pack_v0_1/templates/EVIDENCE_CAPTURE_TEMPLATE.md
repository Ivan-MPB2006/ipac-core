# Evidence Capture Template

## Evidence item

- evidence_id:
- run_id:
- test_step:
- evidence_class:
- observed_behavior:
- expected_behavior:
- pass / partial / fail:

## Interpretation

This evidence can support:

```text

```

This evidence cannot support:

```text

```

## Risk check

- false validation risk:
- drift detected:
- missing context:
- reviewer note:

## Decision impact

- [ ] no impact
- [ ] improve Context Pack
- [ ] rerun step
- [ ] redesign test
- [ ] stop test
