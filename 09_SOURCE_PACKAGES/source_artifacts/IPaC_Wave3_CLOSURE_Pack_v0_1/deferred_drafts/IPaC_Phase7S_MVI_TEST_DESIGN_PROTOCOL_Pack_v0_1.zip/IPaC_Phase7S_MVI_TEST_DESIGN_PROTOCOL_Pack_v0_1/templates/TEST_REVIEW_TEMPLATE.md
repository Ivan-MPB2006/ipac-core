# Phase 7S / 7T Test Review Template

## 1. Test identity

- test_id:
- run_id:
- Context Pack version:
- reviewer:

## 2. Criteria review

| Criterion | Pass / Partial / Fail | Evidence | Note |
|---|---|---|---|
| Coordinates reconstructed |  |  |  |
| Phase boundary held |  |  |  |
| No execution plan |  |  |  |
| Validation levels separated |  |  |  |
| Parked items preserved |  |  |  |
| Controlled review completed |  |  |  |
| Missing context captured |  |  |  |

## 3. Drift review

- context drift events:
- boundary violations:
- hallucinated accepted artifacts:
- false validation claims:

## 4. Decision

- [ ] PASS
- [ ] PARTIAL
- [ ] FAIL
- [ ] REDESIGN

## 5. Required changes

- Context Pack changes:
- Boot prompt changes:
- Stop rule changes:
- Evidence template changes:
