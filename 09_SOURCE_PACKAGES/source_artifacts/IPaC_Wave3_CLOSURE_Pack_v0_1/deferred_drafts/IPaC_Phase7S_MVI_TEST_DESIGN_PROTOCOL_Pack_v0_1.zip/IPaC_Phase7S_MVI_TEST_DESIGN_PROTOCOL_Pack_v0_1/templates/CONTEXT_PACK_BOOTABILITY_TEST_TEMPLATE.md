# Context Pack Bootability Test Template

## Test run metadata

- run_id:
- date:
- tester:
- context_pack_version:
- boot_prompt_version:
- clean_project/chat:

## Input boundary

Provided:

- [ ] Boot Prompt
- [ ] Compact Context Pack
- [ ] System Discipline Rules
- [ ] One controlled task

Not provided:

- [ ] Full old chat
- [ ] Source ZIP bulk
- [ ] Execution artifacts
- [ ] Codex / MCP / RAG tasks
- [ ] Public channel plans

## Boot reconstruction questions

1. Where are we by wave and phase?
2. What is source-of-truth?
3. What is active task?
4. What is forbidden now?
5. What is parked?
6. What criteria show context was recovered?

## Controlled task

Choose one:

- [ ] Mini Artifact Review
- [ ] Mini Need → Artifact → Review

## Review outcome

- [ ] PASS
- [ ] PARTIAL
- [ ] FAIL
- [ ] REDESIGN

## Notes

- drift detected:
- false validation risk:
- missing context:
- pack improvement:
