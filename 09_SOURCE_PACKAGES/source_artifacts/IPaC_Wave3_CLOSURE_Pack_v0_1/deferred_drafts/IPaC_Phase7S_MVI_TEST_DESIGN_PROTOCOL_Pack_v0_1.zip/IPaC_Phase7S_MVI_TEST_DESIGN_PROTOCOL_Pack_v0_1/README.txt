IPaC Phase 7S — MVI Test Design Protocol Pack v0.1

Purpose:
Design the first minimal MVI test without launching an MVP or creating an execution roadmap.

Selected test:
MVI-IPAC-003 — Context Pack Bootability Test

Core companion:
MVI-IPAC-005 — Need → Artifact → Review cycle

This pack contains:
- test design protocol
- Context Pack Bootability Test specification
- success / failure criteria
- evidence capture plan
- stop rules
- false validation guards
- templates for a controlled run
- next prompt for Phase 7T Controlled Test Run

Status:
accepted-candidate / requires manual review before execution.
