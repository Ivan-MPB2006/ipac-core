# PHASE 7T — Boot Reconstruction

## Reconstructed coordinates

```text
Recovery Program
├─ Wave 1 — Core Recovery ✅
├─ Wave 2 — Knowledge Recovery ✅
└─ Wave 3 — Validation / MVP Candidate Recovery
   ├─ Phase 7  — MVP/MVI Candidates ✅
   ├─ Phase 7R — Candidate Review & Selection ✅
   ├─ Phase 7S — MVI Test Design Protocol ✅
   └─ Phase 7T — Controlled Test Run ✅ current
```

## Source-of-truth

```text
IPaC Project Starter Pack v0.2
```

## Active task

```text
MVI-IPAC-003 — Context Pack Bootability Test
```

## What is forbidden now

- MVP launch.
- Execution plan.
- Codex / MCP / RAG / Neo4j implementation.
- External public campaign.
- Field validation claims.
- Full product design.

## What is parked

- Full toolchain.
- Public channels.
- External reviewer loop until field design.
- Full MVP scope.
- Business model.
- Enterprise adoption.

## Bootability criteria

Context is considered reconstructed if the new Project can:

1. Identify current wave and phase.
2. Identify source-of-truth.
3. State active task.
4. State forbidden actions.
5. Identify parked items.
6. Separate bootability evidence from field validation.
7. Perform a small boundary check without scope creep.
