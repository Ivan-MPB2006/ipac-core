# PHASE 7T — Limitations and Clean-room Note

## Primary limitation

This package is produced inside the same working line. Therefore it is not clean-room evidence.

## Clean-room requirement

A true bootability test requires:

1. A fresh Project or chat.
2. No old conversation history.
3. Only the compact Context Pack payload.
4. Fixed boot task.
5. Captured response.
6. Human review against success / failure criteria.

## What to watch

- Does the new Project ask for the full old chat?
- Does it jump to MVP / execution?
- Does it confuse field validation with internal coherence?
- Does it reconstruct parked items?
- Does it preserve source-of-truth discipline?
- Does it identify uncertainty rather than hide it?
