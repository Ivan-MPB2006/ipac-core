IPaC Phase 7T — Controlled Test Run Pack v0.1

Purpose:
Run an internal controlled Context Pack Bootability Test and prepare a clean-room payload for a new Project.

Decision:
PARTIAL PASS — requires clean-room run.

Why partial:
This package can verify that the test protocol and compact context are internally coherent, but only a fresh Project/clean chat can show whether the Context Pack is truly bootable without relying on accumulated conversational history.

Use next:
1. Open payload/CONTEXT_PACK_PAYLOAD_FOR_NEW_PROJECT.md.
2. Paste it into a clean Project/chat.
3. Capture the result using templates/PHASE7T_CLEAN_ROOM_RUN_CAPTURE_TEMPLATE.md.
4. Review with prompts/PHASE7U_TEST_REPORT_REVIEW_PROMPT.md.
