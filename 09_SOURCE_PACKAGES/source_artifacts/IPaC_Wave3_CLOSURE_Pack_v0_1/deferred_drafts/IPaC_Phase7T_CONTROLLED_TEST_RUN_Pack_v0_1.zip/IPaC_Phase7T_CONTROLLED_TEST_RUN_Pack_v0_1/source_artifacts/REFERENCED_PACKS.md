# Referenced packs

This Phase 7T pack is derived from:

- IPaC Project Starter Pack v0.2
- IPaC Knowledge Recovery Pack v0.1
- Phase 7 — MVP/MVI Candidates
- Phase 7R — Candidate Review & Selection Discipline
- Phase 7S — MVI Test Design Protocol

No new web research was performed.
No field validation is claimed.
