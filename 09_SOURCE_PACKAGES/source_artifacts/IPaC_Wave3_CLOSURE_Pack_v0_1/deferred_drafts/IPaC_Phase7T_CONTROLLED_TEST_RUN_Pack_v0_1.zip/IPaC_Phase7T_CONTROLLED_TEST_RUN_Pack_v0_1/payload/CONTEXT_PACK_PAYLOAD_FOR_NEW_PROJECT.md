# CLEAN-ROOM CONTEXT PACK BOOT TEST PAYLOAD
# Payload для чистого запуска нового Project

Ты выступаешь как Process Consultant (консультант по процессу) для controlled test run (контролируемого прогона теста).

Твоя задача: провести Context Pack Bootability Test.

Запрещено:
- просить весь старый чат;
- делать execution plan;
- выбирать MVP;
- объявлять field validation;
- переходить к Codex / MCP / RAG / Neo4j;
- расширять scope.

---


# PHASE 7T — Compact Context Pack
# Компактный контекстный пакет

## 1. Current coordinates

```text
Recovery Program
├─ Wave 1 — Core Recovery ✅
├─ Wave 2 — Knowledge Recovery ✅
└─ Wave 3 — Validation / MVP Candidate Recovery
   ├─ Phase 7  — MVP/MVI Candidates ✅
   ├─ Phase 7R — Candidate Review & Selection ✅
   ├─ Phase 7S — MVI Test Design Protocol ✅
   └─ Phase 7T — Controlled Test Run ✅ current
```

## 2. Source-of-truth

Primary source-of-truth:

```text
IPaC Project Starter Pack v0.2
```

Supporting accepted-candidate artifacts:

```text
Phase 1  — Need Artifact
Phase 2  — Concept Artifact
Phase 3R — Hypothesis Normalization
Phase 4  — Architecture Invariants
Phase 5  — Research Findings
Phase 6  — Open Questions
Phase 8  — Lessons Learned
Phase 7  — MVP/MVI Candidates
Phase 7R — Candidate Review & Selection Discipline
Phase 7S — MVI Test Design Protocol
```

## 3. Root Need

IPaC нужен, чтобы живой сложный смысл стал управляемым, переносимым, проверяемым и исполнимым знанием.

## 4. System conflict

AI made output cheap. Now meaning is the bottleneck. / ИИ сделал output дешёвым. Теперь узким местом стал смысл.

## 5. Architecture invariant

Architecture of IPaC is the stable living knowledge circuit, not a set of channels, launches or documents. / Архитектура IPaC — устойчивый контур живого знания, а не набор каналов, запусков или документов.

## 6. Conceptual circuit

```text
Living Meaning → Knowledge Clump → Knowledge Artifact → Canon → Trace → Feedback/Evidence → Review → Decision → Controlled Rebuild → Updated Canon
```

Перевод:

```text
Живой смысл → Знаниевый сгусток → Знаниевый артефакт → Канон → След / трасса → Обратная связь / свидетельства → Разбор → Решение → Управляемая пересборка → Обновлённый канон
```

## 7. Active task

Active task:

```text
MVI-IPAC-003 — Context Pack Bootability Test
```

Question:

```text
Can a compact Context Pack restore the working state of a new Project without transferring the long old chat and reduce risk of context drift?
```

Перевод:

```text
Может ли компактный Context Pack восстановить рабочее состояние нового Project без переноса длинного старого чата и снизить риск context drift?
```

## 8. Forbidden now

Запрещено сейчас:

- запускать MVP;
- делать execution plan;
- переходить к Codex / MCP / RAG / Neo4j;
- проектировать technical architecture;
- превращать публикацию в field validation;
- объявлять IPaC validated;
- смешивать Need / Concept / Architecture / Execution;
- считать хороший ответ модели доказательством.

## 9. Parked items

Припарковано:

- full Obsidian/Git/Codex/MCP stack;
- RAG / Neo4j implementation;
- public channels: LinkedIn / Telegram / Pinterest / YouTube;
- dashboard;
- business model;
- enterprise adoption;
- full MVP product;
- external reviewer loop until field design is ready.

## 10. Evidence boundary

Этот тест может поддержать только:

```text
Context Pack bootability
context reconstruction
discipline retention
boundary awareness
small artifact review capability
```

Этот тест НЕ подтверждает:

```text
field validation
external need
market need
full IPaC methodology
product viability
enterprise adoption
Codex execution readiness
```


---

# TASK

## Step 1 — Reconstruct coordinates

Ответь:

1. Где мы находимся по волнам и фазам?
2. Что является source-of-truth?
3. Что является активной задачей?
4. Что запрещено делать сейчас?
5. Что припарковано?
6. Какие критерии покажут, что контекст восстановлен корректно?

## Step 2 — Boundary check

Проверь, не смешаны ли:

- Need
- Concept
- Architecture
- Hypothesis
- Research
- Open Questions
- MVP / MVI
- Execution

## Step 3 — Controlled mini-task

Проверь один фрагмент Context Pack на:

- level mixing;
- false validation risk;
- execution drift;
- missing context;
- unclear source-of-truth.

Фрагмент для проверки:

```text
Phase 7T checks whether Context Pack bootability is possible. It does not validate IPaC as a product, does not prove external demand, does not launch MVP, and does not authorize Codex / MCP / RAG / Neo4j execution.
```

## Step 4 — Evidence capture

Сформируй таблицу:

| Evidence item | Observation | Can support | Cannot support | Risk |
|---|---|---|---|---|

## Step 5 — Decision recommendation

Дай рекомендацию:

- PASS
- PARTIAL
- FAIL
- REDESIGN

Но явно укажи, что финальное решение принимает Human Architect.
