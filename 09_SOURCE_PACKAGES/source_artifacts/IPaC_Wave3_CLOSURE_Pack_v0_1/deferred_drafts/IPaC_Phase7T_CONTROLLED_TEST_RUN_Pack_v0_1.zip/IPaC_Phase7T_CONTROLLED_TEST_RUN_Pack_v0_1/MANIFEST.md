# MANIFEST — IPaC Phase 7T Controlled Test Run Pack v0.1

Generated: 2026-06-08T20:03:51Z

## Artifact identity

- Program: IPaC Recovery Program
- Wave: Wave 3 — Validation / MVP Candidate Recovery
- Phase: Phase 7T
- Artifact type: CONTROLLED_TEST_RUN
- Test: MVI-IPAC-003 — Context Pack Bootability Test
- Status: partial-pass / requires-clean-room-run
- Source mode: derived from accepted recovery artifacts and Phase 7S test design

## Included files

```text
START_HERE.md
README.txt
MANIFEST.md

docs/
  PHASE7T_CONTROLLED_TEST_RUN_REPORT.md
  PHASE7T_COMPACT_CONTEXT_PACK.md
  PHASE7T_BOOT_RECONSTRUCTION.md
  PHASE7T_BOUNDARY_CHECK.md
  PHASE7T_CONTROLLED_MINI_TASK_REVIEW.md
  PHASE7T_EVIDENCE_CAPTURE.md
  PHASE7T_DECISION_RECOMMENDATION.md
  PHASE7T_LIMITATIONS_AND_CLEANROOM_NOTE.md
  PHASE7T_NEXT_COORDINATES.md

payload/
  CONTEXT_PACK_PAYLOAD_FOR_NEW_PROJECT.md

registers/
  PHASE7T_BOOT_CHECK_REGISTER.csv
  PHASE7T_BOUNDARY_CHECK_REGISTER.csv
  PHASE7T_EVIDENCE_REGISTER.csv
  PHASE7T_CRITERIA_ASSESSMENT_REGISTER.csv
  PHASE7T_ISSUES_AND_CORRECTIONS_REGISTER.csv
  PHASE7T_DECISION_REGISTER.csv

maps/
  PHASE7T_CONTROLLED_RUN_FLOW.mmd
  PHASE7T_EVIDENCE_DECISION_MAP.mmd

templates/
  PHASE7T_CLEAN_ROOM_RUN_CAPTURE_TEMPLATE.md
  PHASE7T_HUMAN_REVIEW_TEMPLATE.md

prompts/
  CLEAN_ROOM_CONTEXT_PACK_BOOT_TEST_PROMPT.md
  PHASE7U_TEST_REPORT_REVIEW_PROMPT.md

status/
  PHASE7T_status.json

source_artifacts/
  REFERENCED_PACKS.md
```

## Non-goals

- Does not claim field validation.
- Does not launch MVP.
- Does not select product roadmap.
- Does not create execution plan.
- Does not introduce Codex / MCP / RAG / Neo4j execution.
