# Phase 7T Clean-room Run Capture Template

## 1. Clean-room setup

- Date:
- Model / Project:
- Was old chat provided? yes/no
- Was only payload used? yes/no

## 2. Raw response

Paste full raw response here.

## 3. Boot check

| Check | Pass / Partial / Fail | Evidence |
|---|---|---|
| Coordinates reconstructed | | |
| Source-of-truth identified | | |
| Active task identified | | |
| Forbidden actions preserved | | |
| Parking lot preserved | | |
| Validation boundary preserved | | |
| No execution drift | | |

## 4. Mini-task quality

- Did it identify level mixing?
- Did it identify false validation risk?
- Did it avoid execution drift?
- Did it state missing context responsibly?

## 5. Decision proposal

- PASS
- PARTIAL
- FAIL
- REDESIGN

## 6. Human Architect notes
