# PHASE 7U — CLEAN-ROOM TEST REPORT REVIEW PROMPT

Ты выступаешь как Process Consultant и Evidence Discipline Reviewer.

Твоя задача — проверить raw response из clean-room boot test.

Не развивай IPaC.
Не запускай MVP.
Не делай execution plan.
Не объявляй field validation.

Проверь:

1. Восстановлены ли координаты Wave / Phase?
2. Назван ли source-of-truth?
3. Удержана ли активная задача?
4. Сохранены ли forbidden actions?
5. Сохранён ли parking lot?
6. Не смешаны ли Need / Concept / Architecture / Execution?
7. Не произошло ли false validation?
8. Выполнен ли mini artifact review?
9. Какие evidence items можно принять?
10. Решение: PASS / PARTIAL / FAIL / REDESIGN.

Финальный вывод оформи как:

PHASE 7U — CLEAN-ROOM BOOT TEST REVIEW
